// review.js
let courses = ["SYST24444-Mobile Web", "INFO20172-Project Mgt", "PROG20799-Data Structures/C", "PROG32356-.Net/C#", "DBAS32100-Database Mgt"];


// Get all that use CSS Class name
function classChange() {
	var nodelist; 			
	var collection; 	

	// for traditional and for/of loop
	nodelist="";

	// traditional for loop


	// For / Of loop


	// Using arrow function 



	// -------------------------------------------------------------

	collection = "";

	// For / Of loop


	// Using arrow function - This format will not work using .getElementsByClassName 
}

// FOR...OF / Template Literal / .getElementById
function forOf() {
	// Using temporary variables to hold output area and data
 	let myname;
	let myid;
	let out;

	out = document.querySelector("#output2");
	out.innerHTML = "";



} // end of FOR/OF


// Arrow Functions
function arrow() {
	let term;
	let credits = [22, 21, 22, 24];

	let out = document.querySelector("#output3");

	term = "";

	/* Arrow function call */
	var termCredits = (term) => {
		if (term >= 1 && term <= 4) {
		out.innerHTML = `Term ${term} has ${credits[term-1]} credits`;
		}
		else {out.innerHTML = "Out of Range"; }
	}
	
	/* Call function */


	// Arrow function MUST be included BEFORE function call
}


// Classes
function classUsed() {
	let out = document.querySelector("#output4");

	/* Declare Class called Term4 */


	var mycourses = new Array();
/* 	
	mycourses.push(new Term4("SYST24444", "Mobile Web", "4"));
	mycourses.push(new Term4("PROG20799", "Data Structures/C", "4"));
	mycourses.push(new Term4("INFO20172", "Project Mgt", "4"));
	mycourses.push(new Term4("PROG32356", ".NET/C#", "4"));
	mycourses.push(new Term4("DBAS32100", "Database Mgt", "4")); 
*/

	/* Display array based on class in an unordered list */


}
