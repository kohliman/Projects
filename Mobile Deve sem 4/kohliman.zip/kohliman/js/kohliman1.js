var minfoarr=JSON.parse(localStorage.getItem('mpinfo'));
var minfo=minfoarr[0];
const myimg = minfo.studentPic;

function show(){
    document.querySelector("#my").innerHTML = `<img src="../images/${myimg}" id="my" alt="Student's Image">`;


document.querySelector("#mdata").innerHTML+=
`
<h1>${minfo.studentFirst}</h1>
<h2>${minfo.studentLast}</h2>
<h3>${minfo.studentID}</h3>
<h4>${minfo.studentLogin}</h4>
<h5>${minfo.studentProgram}</h5>
<h6>${minfo.studentCampus}</h6>


`;
}

