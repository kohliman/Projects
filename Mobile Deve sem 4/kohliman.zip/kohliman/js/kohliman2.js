var cname=JSON.parse(localStorage.getItem('clname'));
var clinfo=JSON.parse(localStorage.getItem('csinfo'));

function clshow(){
    document.querySelector("#head").innerHTML=`Cluster <strong>${cname}</strong> Book list
    <a id="backButton" href="../index.html">Back</a>
    `;
    
    let tableHTML = `<table border="1">
        <thead>
            <tr>
                <th>ISBN</th>
                <th>Title</th>
                <th>#PAGE</th>
                <th>Authors</th>
                <th>BookCover</th>
            </tr>
        </thead>
        <tbody>`;

    for(let book of clinfo) {
        if(book.cluster === cname) {
            tableHTML += `
                <tr>
                    <td>${book.isbn}</td>
                    <td>${book.title}</td>
                    <td>${book.pages}</td>
                    <td>${book.authors}</td>
                    <td><img src="../images/${book.bookPic}" alt="Book Cover of ${book.title}" width="100"></td>
                    </tr>
            `;
        }
    }

    tableHTML += `</tbody></table>`;
    document.querySelector("#data").innerHTML = tableHTML;
}
