var group=new Array();
var mpinfoarr=new Array();
var csinfo=new Array();
let jd;
class Mpinfo{
constructor(studentFirst,studentLast,studentID,studentLogin,studentProgram,studentCampus,studentPic){
    this.studentFirst = studentFirst;
        this.studentLast = studentLast;
        this.studentID = studentID;
        this.studentLogin = studentLogin;
        this.studentProgram = studentProgram;
        this.studentCampus = studentCampus;
        this.studentPic = studentPic;
    }

}
class Group {
    constructor(cluster, logo) {
        this.cluster = cluster;
        this.logo = logo;
    }
}

class ClusterSpecific {
    constructor(isbn, title, pages, bookPic, description, authors, cluster) {
        this.isbn = isbn;
        this.title = title;
        this.pages = pages;
        this.bookPic = bookPic;
        this.description = description;
        this.authors = authors;
        this.cluster = cluster;
    }
}
function main(){
fetch("data/A2-JSON.json")
.then(res=>res.json())
.then((jdata)=>{
console.log(jdata)
jd=jdata;

document.querySelector("#head").innerHTML+=
`
SYST24444 / Assignment #2 / Fall 2023 ... IT Book Clusters
<hr>`;
document.querySelector("#foot").innerHTML+=
`
<hr>
<button onclick="redirectToKohliman()">Click here to Display Data For kohliman</button>

`
;

let st='';
    
for (let [index, g] of jdata.Groupings.entries()) {
    st+=`
    <figure onclick="storecname(${index})">
    <img src="${g.logo}" alt="logoname" style="border:5px solid blue";></img>
<figcaption>&nbsp ${g.cluster}</figcaption>
</figure>
`;
    }
    document.querySelector('#content').innerHTML+=st;





const man=jdata.Fall2023;
    const info=new Mpinfo(
        man.studentFirst,
        man.studentLast,
        man.studentID,
        man.studentLogin,
        man.studentProgram,
        man.studentCampus,
        man.studentPic
    );
    mpinfoarr.push(info);

    localStorage.setItem('mpinfo',JSON.stringify(mpinfoarr));
    console.log(mpinfoarr);
    for (const g of jdata.Groupings) {
        const grp = new Group(g.cluster, g.logo);
        group.push(grp);
    }
    localStorage.setItem('ginfo',JSON.stringify(group));
    for (const cs of jdata.ClusterSpecifics) {
        const specific = new ClusterSpecific(cs.isbn, cs.title, cs.pages, cs.bookPic, cs.description, cs.authors, cs.cluster);
        csinfo.push(specific);
    }
    localStorage.setItem('csinfo',JSON.stringify(csinfo));
   
   
   
});

}
function redirectToKohliman() {
    window.location.href = "./pages/kohliman.html";
}

function storecname(index){
    const cname=jd.Groupings[index].cluster;
    localStorage.setItem('clname',JSON.stringify(cname));
    alert(`Lets go to the ${cname} page`);
    window.location.href="./pages/cluster.html";
}    