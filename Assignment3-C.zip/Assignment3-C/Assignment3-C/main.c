#include "StackQueue.h"

int main() {
    printf("Hello");
    // Initialize the Queue and Stack
    LList Queue;
    Queue.head = Queue.tail = NULL;  // Initialize an empty list

    printf("Hello");
    LList Stack;
    Stack.head = Stack.tail = NULL;  // Initialize an empty list

    // a) Add values 6, 7, 8, 2, 5 to the queue
    enqueue(6, &Queue);
    enqueue(7, &Queue);
    enqueue(8, &Queue);
    enqueue(2, &Queue);
    enqueue(5, &Queue);
    printf("Queue Created");

    // b) Add values 6, 7, 8, 2, 5 to the stack
    push(6, &Stack);
    push(7, &Stack);
    push(8, &Stack);
    push(2, &Stack);
    push(5, &Stack);
    printf("Hello");

    // c) Remove an element from the stack
    int removedFromStack = pop(&Stack);
    printf("Removed from stack: %d\n", removedFromStack);

    // d) Remove an element from the queue
    int removedFromQueue = dequeue(&Queue);
    printf("Removed from queue: %d\n", removedFromQueue);

    // e) Display the next element to be removed from the stack
    int nextInStack = top(Stack);
    printf("Next element to be removed from stack: %d\n", nextInStack);

    // f) Display the next element to be removed from the queue
    int nextInQueue = peek(Queue);
    printf("Next element to be removed from queue: %d\n", nextInQueue);


    return 0;
}
