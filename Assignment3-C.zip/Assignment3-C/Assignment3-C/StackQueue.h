#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct node {
    int num; // the data in this node of the list
    struct node* next; // the pointer to the next node
} Node, * NodePtr;


typedef struct llist {
    NodePtr head;
    NodePtr tail;
} LList;

// implementation of stack function 
void push(int value, LList* list) {
    NodePtr newNode = (NodePtr)malloc(sizeof(Node));
    if (!newNode) {
        printf("Memory allocation failed\n");
        return;
    }

    newNode->num = value;
    newNode->next = list->head;
    list->head = newNode;

    if (list->tail == NULL) {
        // If the stack was empty, update the tail
        list->tail = newNode;
    }
}


int pop(LList* list) {
    if (list->head == NULL) {
        printf("Stack is empty\n");
        return -1;  // Assuming -1 is not a valid element in the stack
    }

    int value = list->head->num;
    NodePtr temp = list->head;
    list->head = list->head->next;

    if (list->head == NULL) {
        list->tail = NULL;
    }

    free(temp);
    return value;
}
// return the value to be removed

int top(LList list) {
    if (list.head == NULL) {
        printf("Stack is empty\n");
        return -1;  // Assuming -1 is not a valid element in the stack
    }

    return list.head->num;
}
// implementation of the queue using singly linked list
void enqueue(int value, LList* list) {
    NodePtr newNode = (NodePtr)malloc(sizeof(Node));
    if (!newNode) {
        printf("Memory allocation failed\n");
        return;
    }

    newNode->num = value;
    newNode->next = NULL;

    if (list->tail == NULL) {
        list->head = newNode;
        list->tail = newNode;
    }
    else {
        list->tail->next = newNode;
        list->tail = newNode;
    }
}

int dequeue(LList* list) {
    if (list->head == NULL) {
        printf("Queue is empty\n");
        return -1;  // Assuming -1 is not a valid element in the queue
    }

    int value = list->head->num;
    NodePtr temp = list->head;
    list->head = list->head->next;

    if (list->head == NULL) {
        list->tail = NULL;
    }

    free(temp);
    return value;
}


int peek(LList list) {
    if (list.head == NULL) {
        printf("Queue is empty\n");
        return -1;  // Assuming -1 is not a valid element in the queue
    }

    return list.head->num;
}
