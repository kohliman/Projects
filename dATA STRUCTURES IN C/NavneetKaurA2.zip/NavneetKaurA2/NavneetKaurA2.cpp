#include <stdio.h>
//Header
//Navneet Kaur
//991687289
//
//Hello Rachida Amjoun,
//
//This is Navneet Kaur.I wanted to share a brief overview of the Computer Programming
//course I'm exploring at Sheridan College, and I thought you might find it interesting.
//At Sheridan, the Computer Programming course dives deep into the world of coding.It'
//s all about teaching students how to communicate with computers, making them perform
//tasks through code. The journey begins with foundational concepts, gradually progressing to
//more intricate programming challenges. It's like learning a new language; it may seem a bit 
//complex at the outset, but with dedication and practice, it becomes second nature.
//What I appreciate most about the program is its practical approach.Instead of just theoretical 
//learning, there's a significant emphasis on hands-on coding experiences. This immersive learning
//method ensures we grasp concepts more firmly and can apply them in real-world scenarios. And the
//best part? We have an incredibly supportive community of instructors and peers who are always eager to assist whenever challenges arise.
//I'm genuinely excited about everything I'm learning and look forward to applying these skills 
//in the future.I thought sharing this with you would give you a glimpse into my academic journey at Sheridan.
//
//Hope all is well on your end!
//
//Warm regards,
//Navneet Kaur


// Struct representing a 3D vector.
typedef struct Vec3 {
	float x;
	float y;
	float z;
} Vec3;

// Function prototypes
void vec3_Set(Vec3* v, float x, float y, float z);
void vec3_Zero(Vec3* v);
void vec3_Print(const Vec3* v);
void vec3_Add(const Vec3* src1, const Vec3* src2, Vec3* dst);
void vec3_SMul(const Vec3* src, float a, Vec3* dst);

// Also typedef Vec3 as Point to show it can represent a point in space.
typedef struct Vec3 Point;

int main() {
	// Initialize some points and perform operations on them.
	Point P1, P2, P3, P4;
	vec3_Set(&P1, 4.5, 3.5, 1.0);
	vec3_Zero(&P2);
	vec3_Add(&P1, &P2, &P3);
	vec3_SMul(&P3, 0.8, &P4);

	// Print all the points.
	vec3_Print(&P1);
	vec3_Print(&P2);
	vec3_Print(&P3);
	vec3_Print(&P4);

	return 0;
}

// Function implementations

void vec3_Set(Vec3* v, float x, float y, float z) {
	v->x = x;
	v->y = y;
	v->z = z;
}

void vec3_Zero(Vec3* v) {
	v->x = 0;
	v->y = 0;
	v->z = 0;
}

void vec3_Print(const Vec3* v) {
	printf("\nx : %.2f\n y : %.2f \n z: %.2f\n", v->x, v->y, v->z);
}

void vec3_Add(const Vec3* src1, const Vec3* src2, Vec3* dst) {
	dst->x = src1->x + src2->x;
	dst->y = src1->y + src2->y;
	dst->z = src1->z + src2->z;
}

void vec3_SMul(const Vec3* src, float a, Vec3* dst) {
	dst->x = src->x * a;
	dst->y = src->y * a;
	dst->z = src->z * a;
}
