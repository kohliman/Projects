    #define _CRT_SECURE_NO_WARNINGS
    #include "household.h"

    #include <string.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <time.h>
    /*
     * This file gives full implementation of a few functions and gives headers for the rest of the functions that you
     * are required to implement.
     * You may also find all of these functions as part of the TODO list
     */
    Household h = { 0 }; // Zero-initialize the struct


     // sorting function required for ranking of data
    void sortSelection(LocationCountPair arr[], int arrSize) {
        int min = 0, temp = 0;
        char tempStr[20];

        for (int i = 0; i < arrSize; i++)
        {
            min = i;  // record the position of the smallest
            for (int j = i + 1; j < arrSize; j++)
            {
                // update min when finding a smaller element
                if (arr[j].count > arr[min].count)
                    min = j;
            }
            // put the smallest element at position i
            temp = arr[i].count;
            arr[i].count = arr[min].count;
            arr[min].count = temp;
            strcpy(tempStr, arr[i].town);
            strcpy(arr[i].town, arr[min].town);
            strcpy(arr[min].town, tempStr);
        }
    }
    /**
     * This is a generic validation function that takes the upper bound of valid options up to 8 and returns 9 if the user
     * opts to go back to the previous menu instead of providing valid data. Therefore 9 should not be a valid choice!!
     * @param upperbound
     * @return
     */
    int dataValidation(int upperbound) {
        int n = 0, num;
        char temp[40];
        while (1)
        {
            fgets(temp, sizeof(temp), stdin);
            n = sscanf(temp, "%d", &num);
            if (num == 9) return num;
            else if (num >= 0 && num <= upperbound && n == 1) return num;
            else
            {
                printf("Invalid data, Enter an integer 0 through %d or enter 9 to go back to the main menu. Try again \n", upperbound);
                continue;
            }

        } //while loop ends
    }// dataValidation function ends

    // full implementation of regionMapping function is given as a sample to help write other matching functions, if required.
    /**
     *
     * @param x Takes an integer representing a region
     * @return and returns the corresponding region's name
     */
    char* regionMapping(int x)
    {
        char* str;
        switch (x)
        {
        case 0:
            str = "Durham";
            break;
        case 1:
            str = "Peel";
            break;
        case 2:
            str = "York";
            break;
        default:
            str = "York";
        }
        return str;
    }// ends regionMapping function
    /**
     * Full implementation of the menu function is provided that implements entire main user interface of the application.
     * Students are required to implement various functions called in this menu.
     * A list of ToDos is also given for easier development
     * @param top of the list to be provided by reference.
     */
    void menu(NodePtr* top)
    {
        int optionTopLevel = 0;
        while (1)
        {
            // Display a menu to the user
            char temp[120];
            char option[120];
            int valid = 0;
            puts("Menu:");
            printf("Enter your choice to\n");
            printf("1. display households of a race\n");
            printf("2. display households of a region\n");
            printf("3. display households of a town\n");
            printf("4. display households of a region with a given minimum number of people tested positive for Covid-19\n");
            printf("5. display the regions town-wise ranking of number of people fully vaccinated positive for Covid-19\n");
            printf("6. add a record\n");
            puts("7. delete all records of a region, town and race triplet");
            puts("8. display updated data");
            puts("9. store data to a file");
            puts("10. display data from file");
            puts("0. to exit the program");
            scanf("%d", &optionTopLevel);
            int c;
            while ((c = getchar()) != '\n' && c != EOF) {} // input stream flushing

            if (optionTopLevel == 0)
            {
                printf("\nThank you");
                return;
            }
            else if (optionTopLevel > 10)
            {
                printf("Invalid selection, enter an integer 0 through 10, try again\n");
                continue;
            }
            int regionOption = 0, townOption = 0, raceOption = 0, numberTested, numberTestedPos;
            char filename[120] = "..//data//";
            char strTemp[120];
            switch (optionTopLevel) {
            case 1:
                puts("Enter an integer for race: CAUCASIAN (0), INDIGENOUS(1), AFRO AMERICAN(2), ASIAN(3), and OTHER(4)");
                if ((raceOption = dataValidation(4)) == 9) break;
                displayRecordsOfOneRace(*top, raceMapping(raceOption));
                break;
            case 2:
                puts("Enter an integer for region: Durham (0), Peel(1), and York(2):");
                if ((regionOption = dataValidation(2)) == 9) break;

                char* selectedRegion = regionMapping(regionOption);
                displayRecordsOfOneRegion(*top, selectedRegion);
                break;

            case 3:
                puts("Enter an integer for town: OSHAWA(0), WHITBY(1), BRAMPTON(2), MISSISSAUGA(3), MAPLE(4) and VAUGHAN(5)");
                if ((townOption = dataValidation(5)) == 9) break;
                displayRecordsOfOneTown(*top, townMapping(townOption));
                break;
            case 4:
                puts("Enter an integer for region: Durham (0), Peel(1), and York(2):");
                if ((regionOption = dataValidation(2)) == 9) break;

                int numberTestedPos = -1; // Initialize with an invalid value
                while (numberTestedPos <= 0) {
                    char temp[40]; // Buffer to store input string
                    printf("Enter lower bound of number of Covid-19 positive cases per household in the region:\n");
                    fgets(temp, sizeof(temp), stdin); // Read the entire line
                    sscanf(temp, "%d", &numberTestedPos); // Parse the integer

                    if (numberTestedPos <= 0) {
                        puts("Invalid data, enter a positive integer, try again.");
                    }
                }
                // At this point, numberTestedPos is valid and can be used
                // Continue with the rest of the case 4 logic...
                // ...

                displayRecordsOfRegionWithPositiveCases(*top, regionMapping(regionOption), numberTestedPos);
                break;
            case 5:
                regionsTownWiseRankingVaccinated(*top);
                break;
            case 6:
                addNode(top, userInteractionForRecordAddition());
                break;
            case 7:
                puts("Enter region: 0 for Durham, 1 for Peel, 2 for York");
                fgets(temp, sizeof(temp), stdin);
                scanf(temp, "%d", &regionOption);
                if (regionOption == 0) {
                    puts("Enter town: 0 for Oshawa, 1 for Whitby");
                    fgets(temp, sizeof(temp), stdin);
                    scanf(temp, "%d", &townOption);
                }
                else if (regionOption == 1) {
                    puts("Enter town: 0 for Brampton, 1 for Mississauga");
                    fgets(temp, sizeof(temp), stdin);
                    scanf(temp, "%d", &townOption);
                }
                else {
                    puts("Enter town: 0 for Maple, 1 for Vaughan");
                    fgets(temp, sizeof(temp), stdin);
                    scanf(temp, "%d", &townOption);
                }
                puts("Enter race");
                puts("Enter 0 for Caucasian, 1 for indigenous, 2 for African_American, 3 for Asian, 4 for Other");
                fgets(temp, sizeof(temp), stdin);
                scanf(temp, "%d", &raceOption);
                deleteNodesGivenCriteria(top, regionMapping(regionOption), townMappingRegionBased(regionOption, townOption),
                    raceMapping(raceOption));
                break;
            case 8:
                printList(*top);
                break;
            case 9: {
                char filename[120];
                puts("Enter file name with extension, for example clients.txt");
                fgets(filename, sizeof(filename), stdin);
                filename[strcspn(filename, "\n")] = 0; // Remove newline character at the end of input
                writeListToFile(*top, filename);
                break;
            }

            case 10: {
                char filename[120];
                puts("Enter file name with extension, for example clients.txt");
                fgets(filename, sizeof(filename), stdin);
                filename[strcspn(filename, "\n")] = 0; // Remove newline character at the end of input
                displayRecordsFromFile(filename);
                break;
            }

            // switch block ends here

            } // while loop ends

        }
    }// menus function ends
        /**
         * This function takes region integer and town integer, town integer actually represents its town number within that region
         * So if there are three towns in a region, town number 0 corresponds to the first town in that region.
         * Read the header file and carefully go through the ordering of elements of regionArr and townArr. regionArr's elements
         * are in alphabetical order, but try to figure out what is the order of townArr elements?
         * @param region an integer value representing a region
         * @param x representing index value from townsArr array (refer to the header file)
         * @return
         */
        char* townMappingRegionBased(int region, int x) {
            // Mapping towns based on region and town index
            if (region == 0) { // For Durham
                return x == 0 ? "OSHAWA" : "WHITBY";
            }
            else if (region == 1) { // For Peel
                return x == 0 ? "BRAMPTON" : "MISSISSAUGA";
            }
            else { // For York
                return x == 0 ? "MAPLE" : "VAUGHAN";
            }
        }
        // ends townMappingRegionBased function
        /**
         * This is a simple mapping functaion, just like regionMapping function
         * @param x is an integer corresponding to the townArr index
         * @return char array representing name of the town
         */
        char* townMapping(int x) {
            //TODO 11 implement townMapping function
                // Ensure index is within bounds
            if (x >= 0 && x < ARR_TOWN_LEN) {
                return townsArr[x];
            }
            else {
                return "Unknown Town";
            }
        }
        // ends townMapping function
        /**
         *
         * @param x
         * @return
         */
        char* raceMapping(int x)
        {
            //TODO 12 implement raceMapping function
             // Ensure index is within bounds
            if (x >= 0 && x < ARR_RACE_LEN) {
                return racesArr[x];
            }
            else {
                return "Unknown Race";
            }
        }// ends raceMapping function
        /**
         * It populates the linked list with valid random data. The top of the list is passed as a reference i.e. address of the pointer!
         * @param top top is passed by reference i.e. address of the pointer top is passed in the call!
         */
        void initializeData(NodePtr * top) {
            srand(time(NULL));  // Seed the random number generator

            for (int i = 0; i < SIZE; i++) {
                Household h;

                // Generate random data for each household
                int regionIndex = rand() % ARR_REGION_LEN;
                strcpy(h.region, regionsArr[regionIndex]);

                int townIndex = rand() % ARR_TOWN_LEN;
                strcpy(h.town, townsArr[townIndex]);

                int raceIndex = rand() % ARR_RACE_LEN;
                strcpy(h.race, racesArr[raceIndex]);

                h.familySize = (rand() % (MAX_FAMILYSIZE - 1)) + 1;
                h.testedPositive = rand() % (h.familySize + 1);
                h.fullyVaccinated = rand() % (h.familySize + 1);

                // Create a new node and add it to the list
                NodePtr newNode = makeNode(h);
                if (newNode != NULL) {
                    newNode->next = *top;
                    *top = newNode;
                }
            }
        }

        //initializeData ends
        /**
         *
         * @param top is the top of the list
         * @param region is the region that all the displayed records should belong to
         */
        void displayRecordsOfOneRegion(NodePtr top, char region[]) {
            // TODO 02: implement displayRecordsOfOneRegion function
            NodePtr current = top;
            int ctr = 1;
            while (current != NULL) {
                if (strcmp(current->data.region, region) == 0) {
                    printRecord(ctr++, current);
                }
                current = current->next;
            }
        } //ends displayRecordsOfOneRegion
        /**
         *
         * @param top
         * @param town
         */
        void displayRecordsOfOneTown(NodePtr top, char town[]) {
            // TODO 03: implement displayRecordsOfOneTown function
            NodePtr current = top;
            int ctr = 1;
            while (current != NULL) {
                if (strcmp(current->data.town, town) == 0) {
                    printRecord(ctr++, current);
                }
                current = current->next;
            }
        } //ends displayRecordsOfOneTown
        /**
         *
         * @param top
         * @param race
         */
        void displayRecordsOfOneRace(NodePtr top, char race[]) {
            // TODO 04: implement displayRecordsOfOneRace function
            NodePtr current = top;
            int ctr = 1;
            while (current != NULL) {
                if (strcmp(current->data.race, race) == 0) {
                    printRecord(ctr++, current);
                }
                current = current->next;
            }
        } //ends displayRecordsOfOneTown
        /**
         *
         * @param top
         * @param region
         * @param numOfPositiveCases
         */
        void displayRecordsOfRegionWithPositiveCases(NodePtr top, char region[], int numOfPositiveCases) {
            // TODO 05: implement displayRecordsOfRegionWithPositiveCases function
            NodePtr current = top;
            int ctr = 1;
            while (current != NULL) {
                if (strcmp(current->data.region, region) == 0 && current->data.testedPositive > numOfPositiveCases) {
                    printRecord(ctr++, current);
                }
                current = current->next;
            }
        }
        /**
         * This function ranks all the towns in descending order of total number of people vaccinated
         * @param top
         */
        void regionsTownWiseRankingVaccinated(NodePtr top) {
            // TODO 06: implement regionsTownWiseRankingVaccinated function
            LocationCountPair pairs[ARR_TOWN_LEN];
            // Initialize pairs
            for (int i = 0; i < ARR_TOWN_LEN; i++) {
                pairs[i].count = 0;
                strcpy(pairs[i].town, townsArr[i]);
            }
            // Accumulate vaccination counts
            while (top != NULL) {
                for (int i = 0; i < ARR_TOWN_LEN; i++) {
                    if (strcmp(top->data.town, pairs[i].town) == 0) {
                        pairs[i].count += top->data.fullyVaccinated;
                        break;
                    }
                }
                top = top->next;
            }
            // Sort pairs based on vaccination count
            sortSelection(pairs, ARR_TOWN_LEN);
            // Display results
            for (int i = 0; i < ARR_TOWN_LEN; i++) {
                printf("%s: %d\n", pairs[i].town, pairs[i].count);
            }
        } // function regionsTownWiseRankingVaccinated ends
        /**
         * This function gets validated data from the user for adding a record and then invokes makeHousehold function as part
         * of the return statement
         * @return  it returns a household instance that this function creates based on validated user input
         */
       Household userInteractionForRecordAddition() {
        // TODO 07: implement userInteractionForRecordAddition function
        Household h;

        // Prompt user for each field and validate input
        printf("Enter race (0-4): ");
        int raceIndex;
        scanf("%d", &raceIndex);
        strcpy(h.race, raceMapping(raceIndex));

        printf("Enter region (0-2): ");
        int regionIndex;
        scanf("%d", &regionIndex);
        strcpy(h.region, regionMapping(regionIndex));

        printf("Enter town index: ");
        int townIndex;
        scanf("%d", &townIndex);
        strcpy(h.town, townMapping(townIndex));

        printf("Enter family size, tested positive, fully vaccinated: ");
        scanf("%d %d %d", &h.familySize, &h.testedPositive, &h.fullyVaccinated);

        return h;
    }

    /**
     *
     * @param top top of the list to be passed by reference
     * @param region passed as a character array
     * @param town passed as a character array
     * @param race passed as a character array
     */
    void deleteNodesGivenCriteria(NodePtr* top, char region[], char town[], char race[]) {
        //TODO 08: implement deleteNodesGivenCriteria function
        NodePtr current = *top, prev = NULL;
        while (current != NULL) {
            if (strcmp(current->data.region, region) == 0 && strcmp(current->data.town, town) == 0 && strcmp(current->data.race, race) == 0) {
                NodePtr temp = current;
                if (prev == NULL) *top = current->next;
                else prev->next = current->next;
                current = current->next;
                free(temp);
            }
            else {
                prev = current;
                current = current->next;
            }
        }
    }// deleteNodeCriteria function ends
    /**
     * This function prints the entire list of data. It invokes printRecord function
     * @param ptr is the top of the list
     */
    void printList(NodePtr ptr) {
        // TODO 09: implement printList function
        int ctr = 1;
        while (ptr != NULL) {
            printRecord(ctr++, ptr);
            ptr = ptr->next;
        }
        //function printRecord is invoked

    }
    /**
     * It prints a single record starting with a serial number to keep a count of number of records printed
     * @param ctr serial number of the record
     * @param ptr top of the list
     */
    void printRecord(int ctr, NodePtr ptr) {
        // Ensure the node pointer is not NULL
            // TODO 13: implement printRecord function
        if (ptr != NULL) {
            // Print the record details
            printf("%d. Race: %s, Region: %s, Town: %s, ", ctr, ptr->data.race, ptr->data.region, ptr->data.town);
            printf("Family Size: %d, ", ptr->data.familySize);
            printf("Tested Positive: %d, Fully Vaccinated: %d\n", ptr->data.testedPositive, ptr->data.fullyVaccinated);
        }
        // If ptr is NULL, the function does nothing
    }


    /**
     * This function takes data items of a Household record and sets members of a locally declared Household instance and returns it
     * @param race
     * @param region
     * @param town
     * @param familySize
     * @param totPosCovid
     * @param fullyVac
     * @return a Household instance
     */
    Household makeHousehold(char race[], char region[], char town[], int familySize, int totPosCovid, int fullyVac) {
        // TODO 14: implement makeHousehold function
        Household h;
        strcpy(h.race, race);
        strcpy(h.region, region);
        strcpy(h.town, town);
        h.familySize = familySize;
        h.testedPositive = totPosCovid;
        h.fullyVaccinated = fullyVac;
        return h;
    }
    /**
     * makeNode function allocates dynamic memory to create a node, populates with the data based on its argument of type Household
     * and returns the populated node
     * @param num
     * @return
     */
    NodePtr makeNode(Household num) {
        // TODO 15: implement makeNode function
        NodePtr newNode = (NodePtr)malloc(sizeof(Node));
        if (newNode != NULL) {
            newNode->data = num;
            newNode->next = NULL;
        }
        return newNode;
    }
    /**
     * Add node takes a Household instance, creates a node from it and then adds it to the front of the list that it takes as
     * its other argument
     * @param tom
     * @param num
     */
    void addNode(NodePtr* top, Household num) {
        // TODO 16: implement addNode function
        NodePtr newNode = makeNode(num);
        if (newNode != NULL) {
            newNode->next = *top;
            *top = newNode;
        }
    }
    /**
     * THis function deletes a node from the list
     * @param tom takes top of the list as a reference
     */
    void deleteNode(NodePtr* tom) {
        // TODO 17: implement deleteNode function
        if (*tom != NULL) {
            NodePtr temp = *tom;
            *tom = (*tom)->next;
            free(temp);
        }
    }
    /**
     * This function deletes all nodes (records) of the list
     * @param tom
     */
    void deleteAllNodes(NodePtr* tom) {
        // TODO 18: implement deleteAllNodes function
        while (*tom != NULL) {
            deleteNode(tom);
        }
    }
    /**
     * It write all the records to a file. As a sample, clients.txt file is saved in the data folder as part of the project folder
     * @param top
     * @param fileName
     */
    void writeListToFile(NodePtr top, char* fileName) {
        char fullPath[256];
        // Assuming the Data directory is at the project root, no "..//" is necessary
        snprintf(fullPath, sizeof(fullPath), "data/%s", fileName);

        printf("Attempting to open file: %s\n", fullPath); // For debugging

        FILE* file = fopen(fullPath, "w");
        if (file != NULL) {
            // Write to file
            while (top != NULL) {
                fprintf(file, "%s, %s, %s, %d, %d, %d\n",
                    top->data.race, top->data.region, top->data.town,
                    top->data.familySize, top->data.testedPositive, top->data.fullyVaccinated);
                top = top->next;
            }
            fclose(file);
        }
        else {
            puts("Error opening file");
        }
    }


    /**
     * It reads all records from a file
     * @param fileName
     */
    void displayRecordsFromFile(const char* fileName) {
        // The relative path should be "data/clients.txt"
        char fullPath[256];
        snprintf(fullPath, sizeof(fullPath), "%s", fileName);

        FILE* file = fopen(fullPath, "r");
        char line[256];
        if (file != NULL) {
            while (fgets(line, sizeof(line), file)) {
                printf("%s", line);
            }
            fclose(file);
        }
        else {
            perror("Error opening file");
        }
    }

