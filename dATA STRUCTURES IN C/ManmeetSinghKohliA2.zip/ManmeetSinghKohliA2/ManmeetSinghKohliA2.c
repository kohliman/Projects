#include <stdio.h>

//Manmeet Singh Kohli
//991667681
//C
//Rachida Amjoun

//Hello prof,
//This is Manmeet Singh Kohli.I hope you're doing well. 
//I wanted to give you a brief update on my academic journey. Currently,
//I'm enrolled in the SDNE(Software Development and Network Engineering) 
//program at Sheridan College.It's a 3-year advanced diploma course.
//The SDNE program is essentially about diving deep into the world
//of software development and network engineering.It combines the
//intricate world of coding with the ever - evolving realm of network 
//management.Throughout these three years, we get a mix of hands - on 
//coding experience and an understanding of how networks function and are managed.
//It's not just about theory; there's a lot of practical work involved
//, which is fantastic.I'm getting to work on real-life projects, apply 
//coding practices, and learn about maintaining robust networks. It's challenging but equally rewarding.
//I thought of sharing this with you, as you've always shown interest in 
//my endeavors. I'm excited about the journey ahead and the opportunities this course will bring.
//Take care, and hope to catch up soon.
//Best,
//Manmeet Singh Kohli

typedef struct Vec3 {
	float x;
	float y;
	float z;


};
void vec3_Set(struct Vec3* v, float x, float y, float z);
void vec3_Zero(struct Vec3* v);
void vec3_Print(const struct Vec3* v);
void vec3_Add(const struct Vec3* src1,const struct Vec3* src2,struct Vec3* dst);
void vec3_SMul(const struct Vec3* src,float a,struct Vec3* dst);

typedef struct Vec3 Point;

int main() {

	Point P1, P2, P3, P4;
	vec3_Set(&P1, 3, 2, 0);
	vec3_Zero(&P2);
	vec3_Add(&P1, &P2, &P3);
	vec3_SMul(&P3, 1.2, &P4);

	vec3_Print(&P1);
	vec3_Print(&P2);
	vec3_Print(&P3);
	vec3_Print(&P4);



	return 0;
}

void vec3_Set(Point* v ,float x ,float y, float z) {

	v->x = x;
	v->y = y;
	v->z = z;

}

void vec3_Zero(struct Vec3* v) {
	v->x = 0;
	v->y = 0;
	v->z = 0;

}
void vec3_Print(const struct Vec3* v)
{

	printf("\nx : %.2f\n y : %.2f \n z: %.2f\n",v->x,v->y,v->z );
}


void vec3_Add(const struct Vec3* src1, const struct Vec3* src2, struct Vec3* dst) {


	dst->x = src1->x + src2->x;
	dst->y = src1->y + src2->y;
	dst->z = src1->z + src2->z;


}
void vec3_SMul(const struct Vec3* src, float a, struct Vec3* dst)

{

	dst->x = src->x * a;
	dst->y= src->y* a;
	dst->z = src->z * a;


}

