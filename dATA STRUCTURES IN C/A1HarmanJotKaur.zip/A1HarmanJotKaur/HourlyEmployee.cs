﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1HarmanJotKaur
{
    internal class HourlyEmployee : Employee
    {
        public int HoursLogged { get;  set; }
        public double RatePerHour { get;  set; }

        public override double CalculateGrossEarnings() =>
            HoursLogged <= 40 ? RatePerHour * HoursLogged : 40 * RatePerHour + (HoursLogged - 40) * RatePerHour * 1.5;

        public HourlyEmployee(int hoursLogged, double ratePerHour, int id, string fullName)
            : base(id, fullName, EmployeeType.Hourly)
        {
            HoursLogged = hoursLogged;
            RatePerHour = ratePerHour;
        }
        public override string GetDetails()
        {
            return $"{HoursLogged}hrs  ${RatePerHour}/hr";
        }
    }

}
