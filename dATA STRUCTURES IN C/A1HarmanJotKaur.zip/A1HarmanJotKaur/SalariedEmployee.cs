﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1HarmanJotKaur
{
    internal class SalariedEmployee : Employee
    {
        public double FixedSalary { get;  set; }

        public override double CalculateGrossEarnings() => FixedSalary;

        public SalariedEmployee(double fixedSalary, int id, string fullName)
            : base(id, fullName, EmployeeType.Salaried)
        {
            FixedSalary = fixedSalary;
        }
        public override string GetDetails()
        {
            return $"${FixedSalary}/week";
        }
    }

}
