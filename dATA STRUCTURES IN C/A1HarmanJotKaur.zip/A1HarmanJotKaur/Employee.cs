﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1HarmanJotKaur
{
    public abstract class Employee
    {
        public int ID { get;  set; }
        public string FullName { get;  set; }
        public EmployeeType EmpType { get;  set; }
        public abstract double CalculateGrossEarnings();

        public double CalculateTax() => CalculateGrossEarnings() * 0.20;
        public double CalculateNetEarnings() => CalculateGrossEarnings() - CalculateTax();
        public abstract string GetDetails();

        public enum EmployeeType
        {
            Hourly,
            Commission,
            Salaried,
            SalariedCommission
        }

        public Employee(int id, string fullName, EmployeeType empType)
        {
            ID = id;
            FullName = fullName;
            EmpType = empType;
        }
    }

}
