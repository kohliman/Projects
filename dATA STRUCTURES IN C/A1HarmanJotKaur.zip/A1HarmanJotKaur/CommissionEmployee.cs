﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1HarmanJotKaur
{
    internal class CommissionEmployee : Employee
    {
        public double TotalSales { get;  set; }
        public double RateOfCommission { get;  set; }

        public override double CalculateGrossEarnings() => TotalSales * RateOfCommission;

        public CommissionEmployee(double totalSales, double rateOfCommission, int id, string fullName)
            : base(id, fullName, EmployeeType.Commission)
        {
            TotalSales = totalSales;
            RateOfCommission = rateOfCommission;
        }
        public override string GetDetails()
        {
            return $"{TotalSales} sales  {RateOfCommission * 100}%";
        }
    }

}
