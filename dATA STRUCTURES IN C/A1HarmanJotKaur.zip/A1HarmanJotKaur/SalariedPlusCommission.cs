﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1HarmanJotKaur
{
    internal class SalaryPlusCommissionEmployee : CommissionEmployee
    {
        public double BaseSalary { get;  set; }

        public override double CalculateGrossEarnings() => BaseSalary + base.CalculateGrossEarnings();

        public SalaryPlusCommissionEmployee(double baseSalary, double totalSales, double rateOfCommission, int id, string fullName)
            : base(totalSales, rateOfCommission, id, fullName)
        {
            BaseSalary = baseSalary;
        }
        public override string GetDetails()
        {
            return $"{TotalSales} sales  {RateOfCommission * 100}% + ${BaseSalary}/week";
        }
    }

}
