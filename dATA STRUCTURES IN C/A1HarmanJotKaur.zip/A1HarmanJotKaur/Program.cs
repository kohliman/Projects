﻿using ConsoleTables;
using static A1HarmanJotKaur.Employee;

namespace A1HarmanJotKaur
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employeeList = new List<Employee>();
            Console.WriteLine($"{"Assignment 1 by Harmanjot Kaur",90}");

            int uniqueId = 1;
            int primaryChoice = 0;
            int secondaryChoice = 0;

            while (primaryChoice != 6)
            {
                try
                {
                    Console.WriteLine("\nOptions:");
                    Console.WriteLine("1 - Add Employee");
                    Console.WriteLine("2 - Edit Employee");
                    Console.WriteLine("3 - Delete Employee");
                    Console.WriteLine("4 - View Employees");
                    Console.WriteLine("5 - Search Employees");
                    Console.WriteLine("6 - Terminate");

                    Console.WriteLine("\nPick your action\n");
                    primaryChoice = int.Parse(Console.ReadLine());

                    switch (primaryChoice)
                    {
                        case 1:
                            {
                                Console.Clear();

                                while (secondaryChoice != 5)
                                {
                                    string submenu = "\n 1 - add Hourly Employee \n 2 - add Commission Employee\n 3 - add Salaried  Employee \n 4 - add Salaried Plus Commission Employee\n 5 - Return to Main Menu\n";
                                    Console.WriteLine($"{submenu,70}");
                                    Console.WriteLine("\nPick your action");
                                    secondaryChoice = int.Parse(Console.ReadLine());

                                    switch (secondaryChoice)
                                    {
                                        case 1:
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Input Employee Name:");
                                                string fullName = Console.ReadLine();
                                                Console.WriteLine("Input Hours Logged:");
                                                int hoursLogged = int.Parse(Console.ReadLine());
                                                Console.WriteLine("Input Rate Per Hour:");
                                                double ratePerHour = double.Parse(Console.ReadLine());
                                                employeeList.Add(new HourlyEmployee(hoursLogged, ratePerHour, uniqueId, fullName));
                                                uniqueId++;
                                                break;
                                            }

                                        case 2:
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Input Employee Name:");
                                                string fullName = Console.ReadLine();
                                                Console.WriteLine("Input Total Sales:");
                                                double totalSales = double.Parse(Console.ReadLine());
                                                Console.WriteLine("Input Rate of Commission:");
                                                double rateOfCommission = double.Parse(Console.ReadLine());
                                                employeeList.Add(new CommissionEmployee(totalSales, rateOfCommission, uniqueId, fullName));
                                                uniqueId++;
                                                break;
                                            }

                                        case 3:
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Input Employee Name:");
                                                string fullName = Console.ReadLine();
                                                Console.WriteLine("Input Fixed Salary:");
                                                double fixedSalary = double.Parse(Console.ReadLine());
                                                employeeList.Add(new SalariedEmployee(fixedSalary, uniqueId, fullName));
                                                uniqueId++;
                                                break;
                                            }

                                        case 4:
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Input Employee Name:");
                                                string fullName = Console.ReadLine();
                                                Console.WriteLine("Input Base Salary:");
                                                double baseSalary = double.Parse(Console.ReadLine());
                                                Console.WriteLine("Input Total Sales:");
                                                double totalSales = double.Parse(Console.ReadLine());
                                                Console.WriteLine("Input Rate of Commission:");
                                                double rateOfCommission = double.Parse(Console.ReadLine());
                                                employeeList.Add(new SalaryPlusCommissionEmployee(baseSalary, totalSales, rateOfCommission, uniqueId, fullName));
                                                uniqueId++;
                                                break;
                                            }
                                    }
                                }
                                break;
                            }
                        case 2:
                            {
                                Console.Clear();
                                Console.WriteLine("Enter the ID of the employee you want to edit:");
                                int editId = int.Parse(Console.ReadLine());

                                var employeeToEdit = (from e in employeeList
                                                      where e.ID == editId
                                                      select e).FirstOrDefault();

                                if (employeeToEdit == null)
                                {
                                    Console.WriteLine("Employee not found!");
                                    break;
                                }

                                Console.WriteLine($"Editing {employeeToEdit.FullName} ({employeeToEdit.EmpType})");
                                switch (employeeToEdit.EmpType)
                                {
                                    case EmployeeType.Hourly:
                                        {
                                            var hourlyEmployee = employeeToEdit as HourlyEmployee;
                                            Console.WriteLine("Input new Hours Logged:");
                                            hourlyEmployee.HoursLogged = int.Parse(Console.ReadLine());
                                            Console.WriteLine("Input new Rate Per Hour:");
                                            hourlyEmployee.RatePerHour = double.Parse(Console.ReadLine());
                                            break;
                                        }

                                    case EmployeeType.Commission:
                                        {
                                            var commissionEmployee = employeeToEdit as CommissionEmployee;
                                            Console.WriteLine("Input new Total Sales:");
                                            commissionEmployee.TotalSales = double.Parse(Console.ReadLine());
                                            Console.WriteLine("Input new Rate of Commission:");
                                            commissionEmployee.RateOfCommission = double.Parse(Console.ReadLine());
                                            break;
                                        }

                                    case EmployeeType.Salaried:
                                        {
                                            var salariedEmployee = employeeToEdit as SalariedEmployee;
                                            Console.WriteLine("Input new Fixed Salary:");
                                            salariedEmployee.FixedSalary = double.Parse(Console.ReadLine());
                                            break;
                                        }

                                    case EmployeeType.SalariedCommission:
                                        {
                                            var salCommissionEmployee = employeeToEdit as SalaryPlusCommissionEmployee;
                                            Console.WriteLine("Input new Base Salary:");
                                            salCommissionEmployee.BaseSalary = double.Parse(Console.ReadLine());
                                            Console.WriteLine("Input new Total Sales:");
                                            salCommissionEmployee.TotalSales = double.Parse(Console.ReadLine());
                                            Console.WriteLine("Input new Rate of Commission:");
                                            salCommissionEmployee.RateOfCommission = double.Parse(Console.ReadLine());
                                            break;
                                        }
                                }
                                Console.WriteLine("Employee details updated successfully!");
                                break;
                            }

                        case 3:
                            {
                                Console.Clear();

                                Console.WriteLine("Enter the ID of the employee you want to delete:");
                                int deleteId = int.Parse(Console.ReadLine());

                                var employeeToDelete = (from e in employeeList
                                                        where e.ID == deleteId
                                                        select e).SingleOrDefault();

                                if (employeeToDelete != null)
                                {
                                    employeeList.Remove(employeeToDelete);
                                    Console.WriteLine("Employee deleted successfully!");
                                }
                                else
                                {
                                    Console.WriteLine("Employee not found!");
                                }
                                break;
                            }

                        case 4:
                            {
                                Console.Clear();
                                if (!employeeList.Any())
                                {
                                    Console.WriteLine("No employees found.");
                                }
                                else
                                {
                                    var table = new ConsoleTable("ID", "Name", "Type", "Details");

                                    foreach (var employee in employeeList)
                                    {
                                        table.AddRow(employee.ID, employee.FullName, employee.EmpType.ToString(), employee.GetDetails());
                                    }

                                    table.Write(Format.Minimal);
                                }
                                break;
                            }
                        case 5:
                            {
                                Console.Clear();
                                Console.WriteLine("Enter the ID of the employee you want to search for:");
                                int searchId;
                                if (!int.TryParse(Console.ReadLine(), out searchId))
                                {
                                    Console.WriteLine("Invalid input. Please enter a valid ID.");
                                    break;
                                }

                                var matchedEmployees = (from e in employeeList
                                                        where e.ID == searchId
                                                        select e).ToList();

                                if (!matchedEmployees.Any())
                                {
                                    Console.WriteLine($"No employees found with the ID: {searchId}.");
                                }
                                else
                                {
                                    var table = new ConsoleTable("ID", "Name", "Type", "Details");

                                    foreach (var employee in matchedEmployees)
                                    {
                                        string typeDescription = "";
                                        switch (employee.EmpType)
                                        {
                                            case EmployeeType.Hourly:
                                                typeDescription = "Hourly";
                                                break;

                                            case EmployeeType.Commission:
                                                typeDescription = "Commission";
                                                break;

                                            case EmployeeType.Salaried:
                                                typeDescription = "Salaried";
                                                break;

                                            case EmployeeType.SalariedCommission:
                                                typeDescription = "Salary + Comm";
                                                break;
                                        }

                                        table.AddRow(employee.ID, employee.FullName, typeDescription, employee.GetDetails());
                                    }
                                    table.Write(Format.Minimal);
                                }
                                break;
                            }

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("An error occurred: " + ex.Message);
                }
            }
        }

    }
}