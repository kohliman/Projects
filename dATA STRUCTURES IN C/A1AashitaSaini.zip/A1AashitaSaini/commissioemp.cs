﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1AashitaSaini
{
    internal class commissioemp : Employee
    {
        public double GrossSales { get;  set; }
        public double CommissionPercentage { get;  set; }
        private const double MINIMUM_COMMISSION = 100;  // For demonstration purposes, this is a static constant for minimum commission
        private const double SALES_THRESHOLD = 500;  // Threshold for sales to receive actual commission

        public override double GrossEarningsCalculation()
        {
            double commissionValue = GrossSales * CommissionPercentage;
            return (GrossSales < SALES_THRESHOLD) ? MINIMUM_COMMISSION : commissionValue;
        }

        public commissioemp(double salesAmount, double commissionRate, int empId, string name)
            : base(empId, name, EmpClassification.Commission)
        {
            GrossSales = salesAmount;
            CommissionPercentage = commissionRate;
        }

        public override string ProvideDetails()
        {
            return $"{GrossSales} in sales at {CommissionPercentage * 100}% commission rate";
        }
    }
}
