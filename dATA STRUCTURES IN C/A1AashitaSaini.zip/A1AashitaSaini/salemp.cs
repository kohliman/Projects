﻿using System;

namespace A1AashitaSaini
{
    internal class salemo : Employee
    {
        public double WeeklyWage { get;  set; }

        public override double GrossEarningsCalculation() => WeeklyWage;

        public salemo(double weeklySalary, int empId, string name)
            : base(empId, name, EmpClassification.Salary)
        {
            WeeklyWage = weeklySalary;
        }

        public override string ProvideDetails()
        {
            return $"${WeeklyWage} weekly wage";
        }
    }
}
