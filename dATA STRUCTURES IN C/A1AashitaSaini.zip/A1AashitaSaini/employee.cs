﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1AashitaSaini
{
    public abstract class Employee
    {
        // Unique ID for each employee
        public int EmployeeID { get;  set; }

        // Full name of the employee
        public string Name { get;  set; }

        // Type classification of the employee
        public EmpClassification TypeClassification { get;  set; }

        // Abstract method to calculate the gross earnings of an employee
        public abstract double GrossEarningsCalculation();

        // Calculate the tax based on gross earnings
        public double TaxCalculation() => GrossEarningsCalculation() * 0.20;

        // Net earnings after tax deduction
        public double NetEarningsCalculation() => GrossEarningsCalculation() - TaxCalculation();

        // Abstract method to get detailed information of an employee
        public abstract string ProvideDetails();

        // Enumeration for employee classification
        public enum EmpClassification
        {
            Hourly,
            Commission,
            Salary,
            SalaryPlusCommission
        }

        // Constructor initializing employee details
        public Employee(int empId, string name, EmpClassification empClassification)
        {
            EmployeeID = empId;
            Name = name;
            TypeClassification = empClassification;
        }
    }
}
