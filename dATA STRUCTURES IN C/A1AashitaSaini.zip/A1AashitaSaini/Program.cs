﻿
using ConsoleTables;
using static A1AashitaSaini.Employee;

namespace A1AashitaSaini
{
    internal class Program
    {
        private static List<Employee> employees = new List<Employee>();
        private static int nextEmployeeId = 1;

        static void Main(string[] args)
        {
            DisplayWelcomeMessage();

            while (true)
            {
                try {
                    int mainOption = GetMainOption();

                    if (mainOption == 6)
                    {
                        Console.WriteLine("Terminating...");
                        break;
                    }

                    ProcessMainOption(mainOption);
                }catch (Exception ex)
                {
                    Console.WriteLine("Please enter valid input 1-6");
                }
                }
        }

        private static void DisplayWelcomeMessage()
        {
            Console.WriteLine($"{"Assignment 1 by Aashita Saini",90}");
        }

        private static int GetMainOption()
        {
            Console.WriteLine("\nOptions:");
            Console.WriteLine("1 - Add Employee");
            Console.WriteLine("2 - Edit Employee");
            Console.WriteLine("3 - Delete Employee");
            Console.WriteLine("4 - View Employees");
            Console.WriteLine("5 - Search Employees");
            Console.WriteLine("6 - Terminate");

            Console.WriteLine("\nPick your action");
            return int.Parse(Console.ReadLine());
        }

        private static void ProcessMainOption(int option)
        {
            switch (option)
            {
                case 1:
                    AddEmployee();
                    break;
                case 2:
                    EditEmployee();
                    break;

                case 3:
                    DeleteEmployee();
                    break;
                case 4:
                    DisplayAllEmployees();
                    break;
                case 5:
                    SearchAndDisplayEmployee();
                    break;
            }
        }

        private static void AddEmployee()
        {
            Console.Clear();

            while (true)
            {
                Console.WriteLine("Choose type of employee to add:");
                Console.WriteLine("1 - Hourly Employee");
                Console.WriteLine("2 - Commission Employee");
                Console.WriteLine("3 - Salaried Employee");
                Console.WriteLine("4 - Salary Plus Commission Employee");
                Console.WriteLine("5 - Return to Main Menu");

                int choice = int.Parse(Console.ReadLine());

                if (choice == 5)
                {
                    break;
                }

                AddEmployeeOfType(choice);
            }
        }

        private static void AddEmployeeOfType(int choice)
        {
            Console.Clear();
            Console.WriteLine("Input Employee Name:");
            string name = Console.ReadLine();

            switch (choice)
            {
                case 1:
                    Console.WriteLine("Input Hours Logged:");
                    int hours = int.Parse(Console.ReadLine());
                    Console.WriteLine("Input Rate Per Hour:");
                    double rate = double.Parse(Console.ReadLine());
                    employees.Add(new hemployee(hours, rate, nextEmployeeId, name));
                    break;
                case 2:
                    Console.WriteLine("Input Total Sales:");
                    double sales = double.Parse(Console.ReadLine());
                    Console.WriteLine("Input Commission Percentage (as a decimal, e.g., 0.1 for 10%):");
                    double commissionRate = double.Parse(Console.ReadLine());
                    employees.Add(new commissioemp(sales, commissionRate, nextEmployeeId, name));
                    break;
                case 3:
                    Console.WriteLine("Input Weekly Wage:");
                    double weeklyWage = double.Parse(Console.ReadLine());
                    employees.Add(new salemo(weeklyWage, nextEmployeeId, name));
                    break;
                case 4:
                    Console.WriteLine("Input Weekly Base Salary:");
                    double baseSalary = double.Parse(Console.ReadLine());
                    Console.WriteLine("Input Total Sales:");
                    sales = double.Parse(Console.ReadLine());
                    Console.WriteLine("Input Commission Percentage (as a decimal, e.g., 0.1 for 10%):");
                    commissionRate = double.Parse(Console.ReadLine());
                    employees.Add(new salpluscommemp(baseSalary, sales, commissionRate, nextEmployeeId, name));
                    break;
            }

            nextEmployeeId++;
        }

        private static void DeleteEmployee()
        {
            Console.WriteLine("Enter the ID of the employee you want to delete:");
            int deleteId = int.Parse(Console.ReadLine());

            var employeeToDelete = employees.FirstOrDefault(e => e.EmployeeID == deleteId);

            if (employeeToDelete != null)
            {
                employees.Remove(employeeToDelete);
                Console.WriteLine("Employee deleted successfully!");
            }
            else
            {
                Console.WriteLine("Employee not found!");
            }
        }
        private static void DisplayAllEmployees()
        {
            Console.Clear();
            if (!employees.Any())
            {
                Console.WriteLine("No employees found.");
                return;
            }

            DisplayEmployeeTable(employees);
        }

        private static void SearchAndDisplayEmployee()
        {
            Console.Clear();
            Console.WriteLine("Enter the ID of the employee you want to search for:");

            if (!int.TryParse(Console.ReadLine(), out int searchId))
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
                return;
            }

            var matchedEmployees = employees.Where(e => e.EmployeeID == searchId).ToList();

            if (!matchedEmployees.Any())
            {
                Console.WriteLine($"No employees found with the ID: {searchId}.");
                return;
            }

            DisplayEmployeeTable(matchedEmployees);
        }

        private static void DisplayEmployeeTable(List<Employee> employeeList)
        {
            var table = new ConsoleTable("ID", "Name", "Type", "Details");

            foreach (var employee in employeeList)
            {
                table.AddRow(employee.EmployeeID, employee.Name, GetEmployeeTypeDescription(employee.TypeClassification), employee.ProvideDetails());
            }

            table.Write(Format.Minimal);
        }

        private static string GetEmployeeTypeDescription(EmpClassification empType)
        {
            switch (empType)
            {
                case EmpClassification.Hourly:
                    return "Hourly";
                case EmpClassification.Commission:
                    return "Commission";
                case EmpClassification.Salary:
                    return "Salaried";
                case EmpClassification.SalaryPlusCommission:
                    return "Salary + Comm";
                default:
                    return "Unknown";
            }
        }
        private static void EditEmployee()
        {
            Console.Clear();
            Console.WriteLine("Enter the ID of the employee you want to edit:");

            if (!int.TryParse(Console.ReadLine(), out int editId))
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
                return;
            }

            var employeeToEdit = employees.FirstOrDefault(e => e.EmployeeID == editId);

            if (employeeToEdit == null)
            {
                Console.WriteLine("Employee not found!");
                return;
            }

            Console.WriteLine($"Editing {employeeToEdit.Name} ({GetEmployeeTypeDescription(employeeToEdit.TypeClassification)})");

            switch (employeeToEdit.TypeClassification)
            {
                case EmpClassification.Hourly:
                    EditHourlyEmployee(employeeToEdit as hemployee);
                    break;
                case EmpClassification.Commission:
                    EditCommissionEmployee(employeeToEdit as commissioemp);
                    break;
                case EmpClassification.Salary:
                    EditSalariedEmployee(employeeToEdit as salemo);
                    break;
                case EmpClassification.SalaryPlusCommission:
                    EditSalariedCommissionEmployee(employeeToEdit as salpluscommemp);
                    break;
            }

            Console.WriteLine("Employee details updated successfully!");
        }

        private static void EditHourlyEmployee(hemployee employee)
        {
            Console.WriteLine("Input new Hours Logged:");
            employee.WorkedHours = ReadIntegerInput();
            Console.WriteLine("Input new Rate Per Hour:");
            employee.HourlyPaymentRate = ReadDoubleInput();
        }

        private static void EditCommissionEmployee(commissioemp employee)
        {
            Console.WriteLine("Input new Total Sales:");
            employee.GrossSales = ReadDoubleInput();
            Console.WriteLine("Input new Rate of Commission:");
            employee.CommissionPercentage = ReadDoubleInput();
        }

        private static void EditSalariedEmployee(salemo employee)
        {
            Console.WriteLine("Input new Fixed Salary:");
            employee.WeeklyWage = ReadDoubleInput();
        }

        private static void EditSalariedCommissionEmployee(salpluscommemp employee)
        {
            Console.WriteLine("Input new Base Salary:");
            employee.WeeklyBaseSalary = ReadDoubleInput();
            Console.WriteLine("Input new Total Sales:");
            employee.GrossSales = ReadDoubleInput();
            Console.WriteLine("Input new Rate of Commission:");
            employee.CommissionPercentage = ReadDoubleInput();
        }

        private static int ReadIntegerInput()
        {
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out int result))
                    return result;

                Console.WriteLine("Invalid input. Please enter a valid integer:");
            }
        }

        private static double ReadDoubleInput()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double result))
                    return result;

                Console.WriteLine("Invalid input. Please enter a valid number:");
            }
        }


    }

}