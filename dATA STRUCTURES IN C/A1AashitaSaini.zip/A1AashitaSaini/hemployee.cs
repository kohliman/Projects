﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static A1AashitaSaini.Employee;

namespace A1AashitaSaini
{
    internal class hemployee : Employee
    {
        public int WorkedHours { get;  set; }
        public double HourlyPaymentRate { get;  set; }

        public override double GrossEarningsCalculation()
        {
            if (WorkedHours <= 40)
            {
                return HourlyPaymentRate * WorkedHours;
            }
            else if (WorkedHours <= 45)
            {
                return (40 * HourlyPaymentRate) + (WorkedHours - 40) * HourlyPaymentRate * 2;
            }
            else
            {
                return (40 * HourlyPaymentRate) + (5 * HourlyPaymentRate * 2) + (WorkedHours - 45) * HourlyPaymentRate * 2.5;
            }
        }

        public hemployee(int hours, double rate, int empId, string name)
            : base(empId, name, EmpClassification.Hourly)
        {
            WorkedHours = hours;
            HourlyPaymentRate = rate;
        }

        public override string ProvideDetails()
        {
            return $"{WorkedHours} hours at ${HourlyPaymentRate} per hour";
        }
    }
}
