﻿        using A1AashitaSaini;
        using System;
        using System.Collections.Generic;
        using System.Linq;
        using System.Text;
        using System.Threading.Tasks;

        namespace A1AashitaSaini
        {
            internal class salpluscommemp : commissioemp
            {
                public double WeeklyBaseSalary { get;  set; }

                public override double GrossEarningsCalculation() => WeeklyBaseSalary + base.GrossEarningsCalculation();

                public salpluscommemp(double weeklyBase, double salesValue, double commissionPercentage, int empId, string name)
                    : base(salesValue, commissionPercentage, empId, name)
                {
                    WeeklyBaseSalary = weeklyBase;
                }

                public override string ProvideDetails()
                {
                    return $"{GrossSales} sales at {CommissionPercentage * 100}% + ${WeeklyBaseSalary}/week";
                }
            }
        }
