﻿using System;

namespace A1KaramjotSingh
{
    public class hemployee : employee
    {
        public int WorkedHours { get; set; }
        public double HourlyPaymentRate { get; set; }

        public double CalculateSalary()
        {
            if (WorkedHours <= 40)
            {
                return HourlyPaymentRate * WorkedHours;
            }
            else if (WorkedHours <= 45)
            {
                return (40 * HourlyPaymentRate) + (WorkedHours - 40) * HourlyPaymentRate * 2;
            }
            else
            {
                return (40 * HourlyPaymentRate) + (5 * HourlyPaymentRate * 2) + (WorkedHours - 45) * HourlyPaymentRate * 2.5;
            }
        }

        public double CalculateIncomeTax()
        {
            return CalculateSalary() * 0.20;
        }

        public double CalculateNetIncome()
        {
            return CalculateSalary() - CalculateIncomeTax();
        }

        public string DisplayEmployeeInfo()
        {
            return $"Employee ID: {EmployeeID}, Name: {Name}, Classification: {TypeClassification}";
        }

        public hemployee(int hours, double rate, int empId, string name)
            : base(empId, name, EmpClassification.Hourly)
        {
            WorkedHours = hours;
            HourlyPaymentRate = rate;
        }
    }
}
