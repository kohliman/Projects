﻿using ConsoleTables;
using static A1KaramjotSingh.employee;

namespace A1KaramjotSingh
{
    internal class Program
    {
        private static List<employee> employeeData = new List<employee>();
        private static int nextEmployeeId = 1;

        static void Main(string[] args)
        {
            ShowWelcomeMessage();

            while (true)
            {
                try
                {
                    int choice = GetUserChoice();

                    if (choice == 6)
                    {
                        Console.WriteLine("Exiting...");
                        break;
                    }

                    ProcessUserChoice(choice);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Please enter a valid option (1-6)");
                }
            }
        }

        private static void ShowWelcomeMessage()
        {
            Console.WriteLine("Assignment 1 by Karmajot Singh");
        }

        private static int GetUserChoice()
        {
            Console.WriteLine("\nOptions:");
            Console.WriteLine("1 - Add Employee");
            Console.WriteLine("2 - Edit Employee");
            Console.WriteLine("3 - Delete Employee");
            Console.WriteLine("4 - View Employees");
            Console.WriteLine("5 - Search Employees");
            Console.WriteLine("6 - Exit");

            Console.WriteLine("\nEnter your choice:");
            return int.Parse(Console.ReadLine());
        }

        private static void ProcessUserChoice(int option)
        {
            switch (option)
            {
                case 1:
                    AddNewEmployee();
                    break;
                case 2: {

                        break;
                    }
                case 3:
                    Console.Clear();
                    Console.WriteLine("Delete Employee Record:");

                    Console.Write("Enter the ID of the employee you want to delete: ");
                    int deleteId = int.Parse(Console.ReadLine());

                    var employeeToDelete = employeeData.FirstOrDefault(e => e.EmployeeID == deleteId);

                    if (employeeToDelete != null)
                    {
                        employeeData.Remove(employeeToDelete);
                        Console.WriteLine($"Employee {employeeToDelete.Name} deleted successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Employee not found!");
                    }
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine("View All Employee Records:");

                    if (!employeeData.Any())
                    {
                        Console.WriteLine("No employees found.");
                        return;
                    }

                    DisplayEmployeeTable(employeeData);
                    break;
                case 5:
                    Console.Clear();
                    Console.WriteLine("Search for Employee:");

                    Console.Write("Enter the ID of the employee you want to search for: ");
                    if (!int.TryParse(Console.ReadLine(), out int searchId))
                    {
                        Console.WriteLine("Invalid input. Please enter a valid ID.");
                        return;
                    }

                    var matchedEmployees = employeeData.Where(e => e.EmployeeID == searchId).ToList();

                    if (!matchedEmployees.Any())
                    {
                        Console.WriteLine($"No employees found with the ID: {searchId}.");
                        return;
                    }

                    Console.WriteLine("Matching Employee Records:");
                    DisplayEmployeeTable(matchedEmployees);
                    break;
            }
        }

        private static void AddNewEmployee()
        {
            Console.Clear();

            while (true)
            {
                Console.WriteLine("Choose the type of employee to add:");
                Console.WriteLine("1 - Hourly Employee");
                Console.WriteLine("2 - Commission Employee");
                Console.WriteLine("3 - Salaried Employee");
                Console.WriteLine("4 - Salary Plus Commission Employee");
                Console.WriteLine("5 - Return to Main Menu");

                int choice = int.Parse(Console.ReadLine());

                if (choice == 5)
                {
                    break;
                }

                CreateEmployeeOfType(choice);
            }
        }

        private static void CreateEmployeeOfType(int choice)
        {
            Console.Clear();
            Console.WriteLine("Enter Employee Name:");
            string empName = Console.ReadLine();

            switch (choice)
            {
                case 1:
                    Console.WriteLine("Enter Worked Hours:");
                    int workedHours = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Hourly Payment Rate:");
                    double hourlyRate = double.Parse(Console.ReadLine());
                    employeeData.Add(new hemployee(workedHours, hourlyRate, nextEmployeeId, empName));
                    break;
                case 2:
                    Console.WriteLine("Enter Total Sales:");
                    double totalSales = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Commission Percentage (as a decimal, e.g., 0.1 for 10%):");
                    double commissionPercentage = double.Parse(Console.ReadLine());
                    employeeData.Add(new CommEmployee(totalSales, commissionPercentage, nextEmployeeId, empName));
                    break;
                case 3:
                    Console.WriteLine("Enter Weekly Salary:");
                    double weeklySalary = double.Parse(Console.ReadLine());
                    employeeData.Add(new SalEmployee(weeklySalary, nextEmployeeId, empName));
                    break;
                case 4:
                    Console.WriteLine("Enter Weekly Base Salary:");
                    double baseSalary = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Total Sales:");
                    totalSales = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Commission Percentage (as a decimal, e.g., 0.1 for 10%):");
                    commissionPercentage = double.Parse(Console.ReadLine());
                    employeeData.Add(new SalPlusCommEmployee(baseSalary, totalSales, commissionPercentage, nextEmployeeId, empName));
                    break;
            }

            nextEmployeeId++;
        }

    
    private static void DisplayEmployeeTable(List<employee> employeeList)
        {
            ConsoleTable table = new ConsoleTable("Employee ID", "Name", "Classification", "Salary");

            foreach (var employee in employeeList)
            {
                table.AddRow(employee.EmployeeID, employee.Name, employee.TypeClassification, employee.CalculateSalary());
            }

            table.Write();
        }

        private static void EditEmployeeDetails()
        {
            Console.Clear();
            Console.WriteLine("Edit Employee Details:");

            Console.Write("Enter the ID of the employee you want to edit: ");
            if (!int.TryParse(Console.ReadLine(), out int editId))
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
                return;
            }

            var employeeToEdit = employeeData.FirstOrDefault(e => e.EmployeeID == editId);

            if (employeeToEdit == null)
            {
                Console.WriteLine("Employee not found!");
                return;
            }

            Console.WriteLine($"Editing Employee: {employeeToEdit.Name} (Type: {employeeToEdit.TypeClassification})");

            switch (employeeToEdit.TypeClassification)
            {
                case EmpClassification.Hourly:
                    if (employeeToEdit is hemployee hourlyEmployee)
                    {
                        Console.Write("Enter new Worked Hours: ");
                        hourlyEmployee.WorkedHours = ReadIntegerInput();
                        Console.Write("Enter new Hourly Payment Rate: ");
                        hourlyEmployee.HourlyPaymentRate = ReadDoubleInput();
                    }
                    else
                    {
                        Console.WriteLine("Invalid employee type for editing.");
                    }
                    break;
                case EmpClassification.Commission:
                    if (employeeToEdit is CommEmployee commissionEmployee)
                    {
                        Console.Write("Enter new Total Sales: ");
                        commissionEmployee.TotalSales = ReadDoubleInput();
                        Console.Write("Enter new Commission Percentage (as a decimal, e.g., 0.1 for 10%): ");
                        commissionEmployee.CommissionRate = ReadDoubleInput();
                    }
                    else
                    {
                        Console.WriteLine("Invalid employee type for editing.");
                    }
                    break;
                case EmpClassification.Salary:
                    if (employeeToEdit is SalEmployee salariedEmployee)
                    {
                        Console.Write("Enter new Weekly Salary: ");
                        salariedEmployee.WeeklySalaryAmount = ReadDoubleInput();
                    }
                    else
                    {
                        Console.WriteLine("Invalid employee type for editing.");
                    }
                    break;
                case EmpClassification.SalaryPlusCommission:
                    if (employeeToEdit is SalPlusCommEmployee salariedCommissionEmployee)
                    {
                        Console.Write("Enter new Weekly Base Salary: ");
                        salariedCommissionEmployee.WeeklyBaseSalaryAmount = ReadDoubleInput();
                        Console.Write("Enter new Total Sales: ");
                        salariedCommissionEmployee.TotalSales = ReadDoubleInput();
                        Console.Write("Enter new Commission Percentage (as a decimal, e.g., 0.1 for 10%): ");
                        salariedCommissionEmployee.CommissionRate = ReadDoubleInput();
                    }
                    else
                    {
                        Console.WriteLine("Invalid employee type for editing.");
                    }
                    break;
            }

            Console.WriteLine("Employee details updated successfully!");
        }
        private static int ReadIntegerInput()
        {
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out int result))
                    return result;

                Console.WriteLine("Invalid input. Please enter a valid integer:");
            }
        }

        private static double ReadDoubleInput()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double result))
                    return result;

                Console.WriteLine("Invalid input. Please enter a valid number:");
            }
        }


    }
}