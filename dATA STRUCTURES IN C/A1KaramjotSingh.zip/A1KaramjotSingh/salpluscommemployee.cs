﻿using System;

namespace A1KaramjotSingh
{
    public class SalPlusCommEmployee : CommEmployee
    {
        public double WeeklyBaseSalaryAmount { get; set; }

        public  double CalculateSalary()
        {
            return WeeklyBaseSalaryAmount + base.CalculateSalary();
        }

        public SalPlusCommEmployee(double weeklyBaseSalary, double salesAmount, double commissionRate, int empId, string empName)
            : base(salesAmount, commissionRate, empId, empName)
        {
            WeeklyBaseSalaryAmount = weeklyBaseSalary;
        }

        public  string GetEmployeeInfo()
        {
            return $"{TotalSales} in sales at {CommissionRate * 100}% + ${WeeklyBaseSalaryAmount}/week";
        }
    }
}
