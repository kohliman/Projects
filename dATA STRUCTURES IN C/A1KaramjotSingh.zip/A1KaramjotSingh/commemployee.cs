﻿using System;
using static A1KaramjotSingh.employee;
using System.Xml.Linq;

namespace A1KaramjotSingh
{
    public class CommEmployee : employee
    {
        public double TotalSales { get; set; }
        public double CommissionRate { get; set; }

        public double CalculateSalary()
        {
            double minimumCommission = 100;
            double salesThreshold = 500;

            double commission = TotalSales * CommissionRate;
            return (TotalSales < salesThreshold) ? minimumCommission : commission;
        }

        public double CalculateIncomeTax()
        {
            return CalculateSalary() * 0.20;
        }

        public double CalculateNetIncome()
        {
            return CalculateSalary() - CalculateIncomeTax();
        }

        public string DisplayEmployeeInfo()
        {
            return $"{Name} (ID: {EmployeeID}) earned {CalculateSalary():C} in commission";
        }

        public CommEmployee(double totalSales, double commissionRate, int employeeId, string name)
            : base(employeeId, name, EmpClassification.Commission)
        {
            TotalSales = totalSales;
            CommissionRate = commissionRate;
        }
    }
}
