﻿using System;

namespace A1KaramjotSingh
{
    public abstract class employee
    {
        public int EmployeeID { get; set; }
        public string Name { get; set; }
        public EmpClassification TypeClassification { get; set; }

        public double CalculateSalary()
        {
            return 0.0;
        }

        public double CalculateIncomeTax()
        {
            return CalculateSalary() * 0.20;
        }

        public double CalculateNetIncome()
        {
            return CalculateSalary() - CalculateIncomeTax();
        }

        public string DisplayEmployeeInfo()
        {
            return $"Employee ID: {EmployeeID}, Name: {Name}, Classification: {TypeClassification}";
        }

        public enum EmpClassification
        {
            Hourly,
            Commission,
            Salary,
            SalaryPlusCommission
        }

        public employee(int empId, string name, EmpClassification empClassification)
        {
            EmployeeID = empId;
            Name = name;
            TypeClassification = empClassification;
        }
    }
}
