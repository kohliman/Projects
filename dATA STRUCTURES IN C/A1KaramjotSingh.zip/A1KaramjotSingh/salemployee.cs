﻿using System;
using static A1KaramjotSingh.employee;

namespace A1KaramjotSingh
{
    public class SalEmployee : employee
    {
        public string ManagerName { get; set; }
        public double WeeklySalaryAmount { get; set; }

        public double CalculateSalary()
        {
            return WeeklySalaryAmount;
        }

        public double CalculateIncomeTax()
        {
            return CalculateSalary() * 0.20;
        }

        public double CalculateNetIncome()
        {
            return CalculateSalary() - CalculateIncomeTax();
        }

        public string GetManagerInfo()
        {
            return $"Employee ID: {EmployeeID}, Manager Name: {ManagerName}, Weekly Salary: ${WeeklySalaryAmount}";
        }

        public SalEmployee(double weeklySalary, int empId, string name)
            : base(empId, name, EmpClassification.Salary)
        {
            WeeklySalaryAmount = weeklySalary;
        }
    }
}
