﻿using System;

public abstract class Employee
{
	public int Employeeid { get; set; }
    public string Employeename { get; set; }
    public EmployeeType type { get; set; }
    public abstract double GrossEarnings { get; }

    public double Tax => GrossEarnings * 0.20;
    public double NetEarnings => GrossEarnings - Tax;

    public enum EmployeeType
	{
        HourlyEmployee,
        CommissionEmployee,
        SalariedEmployee,
        SalaryPlusCommissionEmployee
    }
    public Employee(int id, string name,EmployeeType etype)
	{
        Employeeid = id;
        Employeename = name;
        type = etype;

	}
}
