﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1NavneetKaur
{
    internal class CommissionEmployee:Employee
    {

        public double GrossSales { get; set; }
        public double CommissionRate { get; set; } 

        public override double GrossEarnings
        {
            get
            {
                return GrossSales * CommissionRate;
            }
        }
        public CommissionEmployee(double grossSales, double commissionRate, int id, string name, EmployeeType etype)
           : base(id, name, etype)
        {
            this.GrossSales = grossSales;
            this.CommissionRate = commissionRate;
        }
    }
}
