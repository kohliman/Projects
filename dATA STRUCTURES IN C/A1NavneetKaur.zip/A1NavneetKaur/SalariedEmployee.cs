﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1NavneetKaur
{
    internal class SalariedEmployee: Employee
    {
        public double WeeklySalary { get; set; }

        public override double GrossEarnings
        {
            get
            {
                return WeeklySalary;
            }
        }

        public SalariedEmployee(double weeklySalary, int id, string name, EmployeeType etype)
            : base(id, name, etype)
        {
            this.WeeklySalary = weeklySalary;
        }
    }
}
