﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1NavneetKaur
{
    internal class HourlyEmployee :Employee
    {
        public int hrs { get; set; }
        public double wage { get; set; }

        public override double GrossEarnings
        {
            get
            {
                if (hrs <= 40)
                    return wage * hrs;
                else
                    return 40 * wage + (hrs - 40) * wage * 1.5;
            }
        }
        public HourlyEmployee(int hrs, double wage, int id, string name, EmployeeType etype) : base(id, name, etype) {
          
            this.hrs = hrs;
            this.wage = wage;

        }






    }
}
