﻿using static Employee;
using ConsoleTables;
namespace A1NavneetKaur
{
    internal class Program
    {

        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>();
            Console.WriteLine($"{"Assignment 1 by Navneet Kaur\n\n\n",70}");

            int id = 1;
            int ch = 0;
            int ch1 = 0;
            
                while (ch != 6)
                {
                try
                {
                    string s = "\n 1 - Add Employee \n 2 - Edit Employee\n 3 - Delete Employee \n 4 - View Employees\n 5 - Search Employees \n 6 - Exit";

                    Console.WriteLine($"{s,100}");
                    Console.WriteLine("\nEnter your choice\n");
                    ch = int.Parse(Console.ReadLine());
                    switch (ch)
                    {
                        case 1:
                            {
                                Console.Clear();


                                while (ch1 != 5)
                                {
                                    string su = "\n 1 - Add Hourly Employee \n 2 - Add Commission Employee\n 3 - Add Salaried  Employee \n 4 - Add Salaried Plus Commission employees\n 5 - Back to Main Menu\n";
                                    Console.WriteLine($"{su,70}");
                                    Console.WriteLine("\nEnter your choice");
                                    ch1 = int.Parse(Console.ReadLine());
                                    switch (ch1)
                                    {

                                        case 1:
                                            {
                                                Console.Clear();

                                                Console.WriteLine("Enter Employee Name:");
                                                string name = Console.ReadLine();

                                                Console.WriteLine("Enter Hours Worked:");
                                                int hrs = int.Parse(Console.ReadLine());

                                                Console.WriteLine("Enter Hourly Wage:");
                                                double wage = double.Parse(Console.ReadLine());

                                                employees.Add(new HourlyEmployee(hrs, wage, id, name, EmployeeType.HourlyEmployee));
                                                id++;

                                                break;
                                            }

                                        case 2:
                                            {
                                                Console.Clear();

                                                Console.WriteLine("Enter Employee Name:");
                                                string name = Console.ReadLine();

                                                Console.WriteLine("Enter Gross Sales:");
                                                double grossSales = double.Parse(Console.ReadLine());

                                                Console.WriteLine("Enter Commission Rate:");
                                                double commissionRate = double.Parse(Console.ReadLine());

                                                employees.Add(new CommissionEmployee(grossSales, commissionRate, id, name, EmployeeType.CommissionEmployee));
                                                id++;
                                                break;
                                            }

                                        case 3:
                                            {
                                                Console.Clear();

                                                Console.WriteLine("Enter Employee Name:");
                                                string name = Console.ReadLine();

                                                Console.WriteLine("Enter Weekly Salary:");
                                                double weeklySalary = double.Parse(Console.ReadLine());

                                                employees.Add(new SalariedEmployee(weeklySalary, id, name, EmployeeType.SalariedEmployee));
                                                id++;
                                                break;
                                            }

                                        case 4:
                                            {
                                                Console.Clear();

                                                Console.WriteLine("Enter Employee Name:");
                                                string name = Console.ReadLine();

                                                Console.WriteLine("Enter Weekly Salary:");
                                                double weeklySalary = double.Parse(Console.ReadLine());

                                                Console.WriteLine("Enter Gross Sales:");
                                                double grossSales = double.Parse(Console.ReadLine());

                                                Console.WriteLine("Enter Commission Rate:");
                                                double commissionRate = double.Parse(Console.ReadLine());

                                                employees.Add(new SalaryPlusCommissionEmployee(weeklySalary, grossSales, commissionRate, id, name, EmployeeType.SalaryPlusCommissionEmployee));
                                                id++;
                                                break;
                                            }
                                    }
                                }
                                break;
                            }
                        case 2:
                            {
                                Console.Clear();

                                Console.WriteLine("Enter the ID of the employee you want to edit:");
                                int editId = int.Parse(Console.ReadLine());

                                var employeeToEdit = (from e in employees where e.Employeeid == editId select e).FirstOrDefault();

                                if (employeeToEdit != null)
                                {
                                    Console.WriteLine("Employee found!");

                                    switch (employeeToEdit.type)
                                    {
                                        case EmployeeType.HourlyEmployee:
                                            HourlyEmployee hourlyEmployee = employeeToEdit as HourlyEmployee;

                                            Console.WriteLine("Enter new hours worked:");
                                            hourlyEmployee.hrs = int.Parse(Console.ReadLine());

                                            Console.WriteLine("Enter new hourly wage:");
                                            hourlyEmployee.wage = double.Parse(Console.ReadLine());

                                            break;

                                        case EmployeeType.CommissionEmployee:
                                            CommissionEmployee commissionEmployee = employeeToEdit as CommissionEmployee;

                                            Console.WriteLine("Enter new gross sales:");
                                            commissionEmployee.GrossSales = double.Parse(Console.ReadLine());

                                            Console.WriteLine("Enter new commission rate:");
                                            commissionEmployee.CommissionRate = double.Parse(Console.ReadLine());

                                            break;

                                        case EmployeeType.SalariedEmployee:
                                            SalariedEmployee salariedEmployee = employeeToEdit as SalariedEmployee;

                                            Console.WriteLine("Enter new weekly salary:");
                                            salariedEmployee.WeeklySalary = double.Parse(Console.ReadLine());

                                            break;

                                        case EmployeeType.SalaryPlusCommissionEmployee:
                                            SalaryPlusCommissionEmployee salaryPlusCommissionEmployee = employeeToEdit as SalaryPlusCommissionEmployee;

                                            Console.WriteLine("Enter new weekly salary:");
                                            salaryPlusCommissionEmployee.WeeklySalary = double.Parse(Console.ReadLine());

                                            Console.WriteLine("Enter new gross sales:");
                                            salaryPlusCommissionEmployee.GrossSales = double.Parse(Console.ReadLine());

                                            Console.WriteLine("Enter new commission rate:");
                                            salaryPlusCommissionEmployee.CommissionRate = double.Parse(Console.ReadLine());

                                            break;
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Employee not found!");
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Clear();

                                Console.WriteLine("Enter the ID of the employee you want to delete:");
                                int deleteId = int.Parse(Console.ReadLine());

                                var employeeToDelete = (from e in employees where e.Employeeid == deleteId select e).FirstOrDefault();

                                if (employeeToDelete != null)
                                {
                                    employees.Remove(employeeToDelete);
                                    Console.WriteLine("Employee deleted successfully!");
                                }
                                else
                                {
                                    Console.WriteLine("Employee not found!");
                                }
                                break;
                            }
                        case 4:
                            {

                                Console.Clear();
                                if (!employees.Any())
                                {
                                    Console.WriteLine("No employees found.");
                                }
                                else
                                {
                                    var table = new ConsoleTable("ID", "Name", "Type", "Details");

                                    foreach (var employee in employees)
                                    {
                                        switch (employee.type)
                                        {
                                            case EmployeeType.HourlyEmployee:
                                                var hourly = employee as HourlyEmployee;
                                                table.AddRow(hourly.Employeeid, hourly.Employeename, "Hourly", $"{hourly.hrs}hrs  ${hourly.wage}/hr");
                                                break;

                                            case EmployeeType.CommissionEmployee:
                                                var commission = employee as CommissionEmployee;
                                                table.AddRow(commission.Employeeid, commission.Employeename, "Commission", $"{commission.GrossSales} sales @ {commission.CommissionRate * 100}%");
                                                break;

                                            case EmployeeType.SalariedEmployee:
                                                var salaried = employee as SalariedEmployee;
                                                table.AddRow(salaried.Employeeid, salaried.Employeename, "Salaried", $"${salaried.WeeklySalary}/week");
                                                break;

                                            case EmployeeType.SalaryPlusCommissionEmployee:
                                                var salPlusComm = employee as SalaryPlusCommissionEmployee;
                                                table.AddRow(salPlusComm.Employeeid, salPlusComm.Employeename, "Salary + Comm", $"{salPlusComm.GrossSales} sales @ {salPlusComm.CommissionRate * 100}% + ${salPlusComm.WeeklySalary}/week");
                                                break;
                                        }
                                    }
                                    table.Write(Format.Minimal);
                                }
                                break;
                            }
                        case 5:
                            {
                                Console.Clear();

                                Console.Clear();
                                Console.WriteLine("Enter the ID of the employee you want to search for:");
                                int searchId;
                                if (!int.TryParse(Console.ReadLine(), out searchId))
                                {
                                    Console.WriteLine("Invalid input. Please enter a valid ID.");
                                    break;
                                }

                                var matchedEmployees = (from e in employees
                                                        where e.Employeeid == searchId
                                                        select e).ToList();

                                if (!matchedEmployees.Any())
                                {
                                    Console.WriteLine($"No employees found with the ID: {searchId}.");
                                }
                                else
                                {
                                    var table = new ConsoleTable("ID", "Name", "Type", "Details");

                                    foreach (var employee in matchedEmployees)
                                    {
                                        switch (employee.type)
                                        {
                                            case EmployeeType.HourlyEmployee:
                                                var hourly = employee as HourlyEmployee;
                                                table.AddRow(hourly.Employeeid, hourly.Employeename, "Hourly", $"{hourly.hrs}hrs @ ${hourly.wage}/hr");
                                                break;

                                            case EmployeeType.CommissionEmployee:
                                                var commission = employee as CommissionEmployee;
                                                table.AddRow(commission.Employeeid, commission.Employeename, "Commission", $"{commission.GrossSales} sales @ {commission.CommissionRate * 100}%");
                                                break;

                                            case EmployeeType.SalariedEmployee:
                                                var salaried = employee as SalariedEmployee;
                                                table.AddRow(salaried.Employeeid, salaried.Employeename, "Salaried", $"${salaried.WeeklySalary}/week");
                                                break;

                                            case EmployeeType.SalaryPlusCommissionEmployee:
                                                var salPlusComm = employee as SalaryPlusCommissionEmployee;
                                                table.AddRow(salPlusComm.Employeeid, salPlusComm.Employeename, "Salary + Comm", $"{salPlusComm.GrossSales} sales @ {salPlusComm.CommissionRate * 100}% + ${salPlusComm.WeeklySalary}/week");
                                                break;
                                        }
                                    }
                                    table.Write(Format.Minimal);
                                }
                                break;
                            }
                        case 6:

                            {
                                Console.Clear();


                                break;
                            }
                        default:
                            {
                                Console.WriteLine("Please enter a valid choice Number between 1-6");
                                break;
                            }

                    }

                    Console.Clear();
                }
                catch (Exception ex)
                {
                    Console.Clear();
                    Console.WriteLine("\n\n\n\nPlease enter valid choice between 1-6");
                }
            }
            Console.WriteLine("\n\nThe program is exited");

        }
    }
        }
    
