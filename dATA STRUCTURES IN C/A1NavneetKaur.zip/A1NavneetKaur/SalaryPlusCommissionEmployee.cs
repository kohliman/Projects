﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1NavneetKaur
{
    internal class SalaryPlusCommissionEmployee:CommissionEmployee
    {
        public double WeeklySalary { get; set; }

        public override double GrossEarnings
        {
            get
            {
                return WeeklySalary + base.GrossEarnings;
            }
        }

        public SalaryPlusCommissionEmployee(double weeklySalary, double grossSales, double commissionRate, int id, string name, EmployeeType etype)
            : base(grossSales, commissionRate, id, name, etype)
        {
            this.WeeklySalary = weeklySalary;
        }
    }

}

