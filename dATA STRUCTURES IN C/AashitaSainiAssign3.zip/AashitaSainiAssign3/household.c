#define _CRT_SECURE_NO_WARNINGS
#include "household.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/*
 * This file gives full implementation of a few functions and gives headers for the rest of the functions that you
 * are required to implement.
 * You may also find all of these functions as part of the TODO list
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "household.h"
 // sorting function required for ranking of data
void sortSelection(LocationCountPair arr[], int arrSize) {
    int min = 0, temp = 0;
    char tempStr[20];

    for (int i = 0; i < arrSize; i++)
    {
        min = i;  // record the position of the smallest
        for (int j = i + 1; j < arrSize; j++)
        {
            // update min when finding a smaller element
            if (arr[j].count > arr[min].count)
                min = j;
        }
        // put the smallest element at position i
        temp = arr[i].count;
        arr[i].count = arr[min].count;
        arr[min].count = temp;
        strcpy(tempStr, arr[i].town);
        strcpy(arr[i].town, arr[min].town);
        strcpy(arr[min].town, tempStr);
    }
}
/**
 * This is a generic validation function that takes the upper bound of valid options up to 8 and returns 9 if the user
 * opts to go back to the previous menu instead of providing valid data. Therefore 9 should not be a valid choice!!
 * @param upperbound
 * @return
 */
int dataValidation(int upperbound) {
    int n = 0, num;
    char temp[40];
    while (1)
    {
        fgets(temp, sizeof(temp), stdin);
        n = sscanf(temp, "%d", &num);
        if (num == 9) return num;
        else if (num >= 0 && num <= upperbound && n == 1) return num;
        else
        {
            printf("Invalid data, Enter an integer 0 through %d or enter 9 to go back to the main menu. Try again \n", upperbound);
            continue;
        }

    } //while loop ends
}// dataValidation function ends

// full implementation of regionMapping function is given as a sample to help write other matching functions, if required.
/**
 *
 * @param x Takes an integer representing a region
 * @return and returns the corresponding region's name
 */
char* regionMapping(int x)
{
    char* str;
    switch (x)
    {
    case 0:
        str = "Durham";
        break;
    case 1:
        str = "Peel";
        break;
    case 2:
        str = "York";
        break;
    default:
        str = "York";
    }
    return str;
}// ends regionMapping function
/**
 * Full implementation of the menu function is provided that implements entire main user interface of the application.
 * Students are required to implement various functions called in this menu.
 * A list of ToDos is also given for easier development
 * @param top of the list to be provided by reference.
 */
void menu(NodePtr* top)
{
    int optionTopLevel = 0;
    while (1)
    {
        // Display a menu to the user
        char temp[120];
        char option[120];
        int valid = 0;
        puts("Menu:");
        printf("Enter your choice to\n");
        printf("1. display households of a race\n");
        printf("2. display households of a region\n");
        printf("3. display households of a town\n");
        printf("4. display households of a region with a given minimum number of people tested positive for Covid-19\n");
        printf("5. display the regions town-wise ranking of number of people fully vaccinated positive for Covid-19\n");
        printf("6. add a record\n");
        puts("7. delete all records of a region, town and race triplet");
        puts("8. display updated data");
        puts("9. store data to a file");
        puts("10. display data from file");
        puts("0. to exit the program");
        scanf("%d", &optionTopLevel);
        int c;
        while ((c = getchar()) != '\n' && c != EOF) {} // input stream flushing

        if (optionTopLevel == 0)
        {
            printf("\nThank you");
            return;
        }
        else if (optionTopLevel > 10)
        {
            printf("Invalid selection, enter an integer 0 through 10, try again\n");
            continue;
        }
        int regionOption = 0, townOption = 0, raceOption = 0, numberTested, numberTestedPos;
        char filename[120] = "..//data//";
        char strTemp[120];
        switch (optionTopLevel) {
        case 1:
            puts("Enter an integer for race: CAUCASIAN (0), INDIGENOUS(1), AFRO AMERICAN(2), ASIAN(3), and OTHER(4)");
            if ((raceOption = dataValidation(4)) == 9) break;
            displayRecordsOfOneRace(*top, raceMapping(raceOption));
            break;
        case 2:
            puts("Enter an integer for region: Durham (0), Peel(1), and York(2):");
            if ((regionOption = dataValidation(2)) == 9) break;
            displayRecordsOfOneRegion(*top, regionMapping(regionOption));
            break;
        case 3:
            puts("Enter an integer for town: OSHAWA(0), WHITBY(1), BRAMPTON(2), MISSISSAUGA(3), MAPLE(4) and VAUGHAN(5)");
            if ((townOption = dataValidation(5)) == 9) break;
            displayRecordsOfOneTown(*top, townMapping(townOption));
            break;
        case 4:
            puts("Enter an integer for region: Durham (0), Peel(1), and York(2):");
            if ((regionOption = dataValidation(2)) == 9) break;
            while (valid != 1) {
                puts("Enter lowerbound of number of Covid-19 positive cases per household in the region\n");
                fgets(temp, sizeof(temp), stdin);
                sscanf(temp, "%d", &numberTestedPos);
                if (numberTestedPos <= 0) {
                    puts("Invalid data, enter a positive integer, try again");
                    continue;
                }
                else valid = 1; // setting valid flag
            }
            valid = 0; // resetting valid flag for next iteration
            displayRecordsOfRegionWithPositiveCases(*top, regionMapping(regionOption), numberTestedPos);
            break;
        case 5:
            regionsTownWiseRankingVaccinated(*top);
            break;
        case 6:
            addNode(top, userInteractionForRecordAddition());
            break;
        case 7:
            puts("Enter region: 0 for Durham, 1 for Peel, 2 for York");
            fgets(temp, sizeof(temp), stdin);
            sscanf(temp, "%d", &regionOption);
            if (regionOption == 0) {
                puts("Enter town: 0 for Oshawa, 1 for Whitby");
                fgets(temp, sizeof(temp), stdin);
                sscanf(temp, "%d", &townOption);
            }
            else if (regionOption == 1) {
                puts("Enter town: 0 for Brampton, 1 for Mississauga");
                fgets(temp, sizeof(temp), stdin);
                sscanf(temp, "%d", &townOption);
            }
            else {
                puts("Enter town: 0 for Maple, 1 for Vaughan");
                fgets(temp, sizeof(temp), stdin);
                sscanf(temp, "%d", &townOption);
            }
            puts("Enter race");
            puts("Enter 0 for Caucasian, 1 for indigenous, 2 for African_American, 3 for Asian, 4 for Other");
            fgets(temp, sizeof(temp), stdin);
            sscanf(temp, "%d", &raceOption);
            deleteNodesGivenCriteria(top, regionMapping(regionOption), townMappingRegionBased(regionOption, townOption),
                raceMapping(raceOption));
            break;
        case 8:
            printList(*top);
            break;
        case 9:
            puts("Enter file name with extension, for example clients.txt");
            fgets(temp, sizeof(temp), stdin);
            sscanf(temp, "%s", strTemp);
            writeListToFile(*top, strcat(filename, strTemp));
            break;
        case 10:
            puts("Enter file name with extension, for example clients.txt");
            fgets(temp, sizeof(temp), stdin);
            sscanf(temp, "%s", strTemp);
            displayRecordsFromFile(strcat(filename, strTemp));
            break;
        default:
            puts("Invalid option");
        } // switch block ends here

    } // while loop ends

}// menus function ends
    /**
     * This function takes region integer and town integer, town integer actually represents its town number within that region
     * So if there are three towns in a region, town number 0 corresponds to the first town in that region.
     * Read the header file and carefully go through the ordering of elements of regionArr and townArr. regionArr's elements
     * are in alphabetical order, but try to figure out what is the order of townArr elements?
     * @param region an integer value representing a region
     * @param x representing index value from townsArr array (refer to the header file)
     * @return
     */
char* townMappingRegionBased(int region, int x) {
    // Define arrays for towns in each region
    char* durhamTowns[] = { "OSHAWA", "WHITBY" };
    char* peelTowns[] = { "BRAMPTON", "MISSISSAUGA" };
    char* yorkTowns[] = { "MAPLE", "VAUGHAN" };

    // Calculate the total number of towns in each region
    int durhamCount = sizeof(durhamTowns) / sizeof(char*);
    int peelCount = sizeof(peelTowns) / sizeof(char*);
    int yorkCount = sizeof(yorkTowns) / sizeof(char*);

    // Use region and town index to select the appropriate town
    char* townName = NULL;

    switch (region) {
    case 0: // For Durham
        if (x >= 0 && x < durhamCount) {
            townName = durhamTowns[x];
        }
        break;
    case 1: // For Peel
        if (x >= 0 && x < peelCount) {
            townName = peelTowns[x];
        }
        break;
    default: // For York
        if (x >= 0 && x < yorkCount) {
            townName = yorkTowns[x];
        }
        break;
    }

    // If townName is still NULL, it means an invalid region or town index was provided
    if (townName == NULL) {
        townName = "Unknown Town";
    }

    return townName;
}



typedef struct {
    int index;
    const char* town;
} TownMapping;

TownMapping townMappings[] = {
    {0, "OSHAWA"},
    {1, "WHITBY"},
    {2, "BRAMPTON"},
    {3, "MISSISSAUGA"},
    {4, "MAPLE"},
    {5, "VAUGHAN"},
};

char* townMapping(int x) {
    //TODO 11 implement townMapping function
    int numMappings = sizeof(townMappings) / sizeof(townMappings[0]);

    for (int i = 0; i < numMappings; i++) {
        if (townMappings[i].index == x) {
            return townMappings[i].town;
        }
    }

    return "Unknown Town";
}


// ends townMappingRegionBased function
/**
 *
 * @param x
 * @return
 */
char* raceMapping(int x) {
    // TODO 12: implement raceMapping function

    static const char raceNames[ARR_RACE_LEN][RACE_NAME_LEN] = {
        {"CAUCASIAN"},
        {"INDIGENOUS"},
        {"AFRO-AMERICAN"},
        {"ASIAN"},
        {"OTHER"}
    };

    if (x >= 0 && x < ARR_RACE_LEN) {
        return raceNames[x];
    }
    else {
        return "Unknown Race";
    }
}
// ends raceMapping function
/**
 * It populates the linked list with valid random data. The top of the list is passed as a reference i.e. address of the pointer!
 * @param top top is passed by reference i.e. address of the pointer top is passed in the call!
 */
void initializeData(NodePtr* top) {
    srand(time(NULL));  // Seed the random number generator

    for (int i = 0; i < SIZE; i++) {
        Household h;

        // Generate random data for each household
        int regionIndex = rand() % ARR_REGION_LEN;
        strcpy(h.region, regionsArr[regionIndex]);

        int townIndex = rand() % ARR_TOWN_LEN;
        strcpy(h.town, townsArr[townIndex]);

        int raceIndex = rand() % ARR_RACE_LEN;
        strcpy(h.race, racesArr[raceIndex]);

        h.familySize = (rand() % (MAX_FAMILYSIZE - 1)) + 1;
        h.testedPositive = rand() % (h.familySize + 1);
        h.fullyVaccinated = rand() % (h.familySize + 1);

        // Create a new node and add it to the list
        NodePtr newNode = makeNode(h);
        if (newNode != NULL) {
            newNode->next = *top;
            *top = newNode;
        }
    }
}


//initializeData ends
/**
 *
 * @param top is the top of the list
 * @param region is the region that all the displayed records should belong to
 */
void displayRecordsOfOneRegion(NodePtr top, char region[]) {
    // TODO 02: implement displayRecordsOfOneRegion function
    NodePtr current = top;
    int ctr = 1;
    while (current != NULL) {
        if (strcmp(current->data.region, region) == 0) {
            printRecord(ctr++, current);
        }
        current = current->next;
    }
} //ends displayRecordsOfOneRegion
/**
 *
 * @param top
 * @param town
 */
void displayRecordsOfOneTown(NodePtr top, char town[]) {
    // TODO 03: implement displayRecordsOfOneTown function
    NodePtr current = top;
    int ctr = 1;
    while (current != NULL) {
        if (strcmp(current->data.town, town) == 0) {
            printRecord(ctr++, current);
        }
        current = current->next;
    }
} //ends displayRecordsOfOneTown
/**
 *
 * @param top
 * @param race
 */
void displayRecordsOfOneRace(NodePtr top, char race[]) {
    // TODO 04: implement displayRecordsOfOneRace function
    NodePtr current = top;
    int ctr = 1;
    while (current != NULL) {
        if (strcmp(current->data.race, race) == 0) {
            printRecord(ctr++, current);
        }
        current = current->next;
    }
} //ends displayRecordsOfOneTown
/**
 *
 * @param top
 * @param region
 * @param numOfPositiveCases
 */
void displayRecordsOfRegionWithPositiveCases(NodePtr top, char region[], int numOfPositiveCases) {
    // TODO 05: implement displayRecordsOfRegionWithPositiveCases function
    int ctr = 1;
    for (NodePtr current = top; current != NULL; current = current->next) {
        if (strcmp(current->data.region, region) == 0 && current->data.testedPositive > numOfPositiveCases) {
            printRecord(ctr++, current);
        }
    }
}

/**
 * This function ranks all the towns in descending order of total number of people vaccinated
 * @param top
 */
void regionsTownWiseRankingVaccinated(NodePtr top) {
    // TODO 06: implement regionsTownWiseRankingVaccinated function
    // Create an array to store town-wise vaccination counts
    int counts[ARR_TOWN_LEN] = { 0 };

    // Accumulate vaccination counts for each town
    while (top != NULL) {
        for (int i = 0; i < ARR_TOWN_LEN; i++) {
            if (strcmp(top->data.town, townsArr[i]) == 0) {
                counts[i] += top->data.fullyVaccinated;
                break;
            }
        }
        top = top->next;
    }

    // Sort towns based on vaccination count using selection sort in descending order
    for (int i = 0; i < ARR_TOWN_LEN - 1; i++) {
        int maxIndex = i;
        for (int j = i + 1; j < ARR_TOWN_LEN; j++) {
            if (counts[j] > counts[maxIndex]) {
                maxIndex = j;
            }
        }
        // Swap counts[i] and counts[maxIndex]
        int temp = counts[i];
        counts[i] = counts[maxIndex];
        counts[maxIndex] = temp;

        // Swap corresponding towns in townsArr
        char tempTown[TOWN_NAME_LEN];
        strcpy(tempTown, townsArr[i]);
        strcpy(townsArr[i], townsArr[maxIndex]);
        strcpy(townsArr[maxIndex], tempTown);
    }

    // Display results
    for (int i = 0; i < ARR_TOWN_LEN; i++) {
        printf("%s: %d\n", townsArr[i], counts[i]);
    }
}
// function regionsTownWiseRankingVaccinated ends
/**
 * This function gets validated data from the user for adding a record and then invokes makeHousehold function as part
 * of the return statement
 * @return  it returns a household instance that this function creates based on validated user input
 */
Household userInteractionForRecordAddition() {
    // TODO 07: implement userInteractionForRecordAddition function
    Household h;

    // Prompt user for each field and validate input
    h.race[0] = '\0'; // Initialize race field to an empty string
    while (strlen(h.race) == 0) {
        printf("Enter race (0-4): ");
        int raceIndex;
        scanf("%d", &raceIndex);
        if (raceIndex >= 0 && raceIndex < ARR_RACE_LEN) {
            strcpy(h.race, raceMapping(raceIndex));
        }
        else {
            printf("Invalid race index. Please enter a valid index.\n");
        }
    }

    h.region[0] = '\0'; // Initialize region field to an empty string
    while (strlen(h.region) == 0) {
        printf("Enter region (0-2): ");
        int regionIndex;
        scanf("%d", &regionIndex);
        if (regionIndex >= 0 && regionIndex < ARR_REGION_LEN) {
            strcpy(h.region, regionMapping(regionIndex));
        }
        else {
            printf("Invalid region index. Please enter a valid index.\n");
        }
    }

    h.town[0] = '\0'; // Initialize town field to an empty string
    while (strlen(h.town) == 0) {
        printf("Enter town index: ");
        int townIndex;
        scanf("%d", &townIndex);
        if (townIndex >= 0 && townIndex < ARR_TOWN_LEN) {
            strcpy(h.town, townMapping(townIndex));
        }
        else {
            printf("Invalid town index. Please enter a valid index.\n");
        }
    }

    printf("Enter family size, tested positive, fully vaccinated: ");
    scanf("%d %d %d", &h.familySize, &h.testedPositive, &h.fullyVaccinated);

    return h;
}
    
/**
 *
 * @param top top of the list to be passed by reference
 * @param region passed as a character array
 * @param town passed as a character array
 * @param race passed as a character array
 */
void deleteNodesGivenCriteria(NodePtr* top, char region[], char town[], char race[]) {
    // TODO 08: implement deleteNodesGivenCriteria function
    NodePtr current = *top, prev = NULL;
    for (; current != NULL; current = current->next) {
        if (strcmp(current->data.region, region) == 0 &&
            strcmp(current->data.town, town) == 0 &&
            strcmp(current->data.race, race) == 0) {
            NodePtr temp = current;
            if (prev == NULL) {
                *top = current->next;
            }
            else {
                prev->next = current->next;
            }
            free(temp);
        }
        else {
            prev = current;
        }
    }
}
// deleteNodeCriteria function ends
/**
 * This function prints the entire list of data. It invokes printRecord function
 * @param ptr is the top of the list
 */
void printList(NodePtr ptr) {
    // TODO 09: implement printList function
    int ctr = 1;
    while (ptr != NULL) {
        printRecord(ctr++, ptr);
        ptr = ptr->next;
    }
    //function printRecord is invoked

}
/**
 * It prints a single record starting with a serial number to keep a count of number of records printed
 * @param ctr serial number of the record
 * @param ptr top of the list
 */
void printRecord(int ctr, NodePtr ptr) {
    // TODO 13: implement printRecord function

    if (ptr != NULL) {
        printf("[%d] - Region: %s | Town: %s | Race: %s | ", ctr, ptr->data.region, ptr->data.town, ptr->data.race);
        printf("Family Size: %d, Positive Cases: %d, Vaccinated: %d\n", ptr->data.familySize, ptr->data.testedPositive, ptr->data.fullyVaccinated);
    }
}


/**
 * This function takes data items of a Household record and sets members of a locally declared Household instance and returns it
 * @param race
 * @param region
 * @param town
 * @param familySize
 * @param totPosCovid
 * @param fullyVac
 * @return a Household instance
 */
Household makeHousehold(char race[], char region[], char town[], int familySize, int totPosCovid, int fullyVac) {
    // TODO 14: implement makeHousehold function
    Household h;
    strcpy(h.race, race);
    strcpy(h.region, region);
    strcpy(h.town, town);
    h.familySize = familySize;
    h.testedPositive = totPosCovid;
    h.fullyVaccinated = fullyVac;
    return h;
}
/**
 * makeNode function allocates dynamic memory to create a node, populates with the data based on its argument of type Household
 * and returns the populated node
 * @param num
 * @return
 */
NodePtr makeNode(Household num) {
    // TODO 15: implement makeNode function
    NodePtr createdNode = (NodePtr)malloc(sizeof(Node));
    if (createdNode != NULL) {
        createdNode->data = num;
        createdNode->next = NULL;
    }
    return createdNode;
}

/**
 * Add node takes a Household instance, creates a node from it and then adds it to the front of the list that it takes as
 * its other argument
 * @param tom
 * @param num
 */
void addNode(NodePtr* top, Household num) {
    // TODO 16: implement addNode function
    NodePtr newNode = makeNode(num);
    if (newNode != NULL) {
        newNode->next = *top;
        *top = newNode;
    }
}
/**
 * THis function deletes a node from the list
 * @param tom takes top of the list as a reference
 */
void deleteNode(NodePtr* tom) {
    // TODO 17: implement deleteNode function
    if (*tom != NULL) {
        NodePtr temp = *tom;
        *tom = (*tom)->next;
        free(temp);
    }
}
/**
 * This function deletes all nodes (records) of the list
 * @param tom
 */
void deleteAllNodes(NodePtr* tom) {
    // TODO 18: implement deleteAllNodes function
    while (*tom != NULL) {
        deleteNode(tom);
    }
}
/**
 * It write all the records to a file. As a sample, clients.txt file is saved in the data folder as part of the project folder
 * @param top
 * @param fileName
 */
void writeListToFile(NodePtr top, char fileName[]) {
    // TODO 19: implement writeListToFile function
    FILE* file = fopen(fileName, "wb"); // Open the file for writing in binary mode

    if (file == NULL) {
        printf("Failed to open the file for writing.\n");
        return;
    }

    // Write a header indicating the number of records
    int recordCount = 0;
    NodePtr current = top;
    while (current != NULL) {
        recordCount++;
        current = current->next;
    }
    fwrite(&recordCount, sizeof(int), 1, file);

    // Traverse the linked list and write each record to the file
    while (top != NULL) {
        Household record = top->data;
        fwrite(record.race, sizeof(char), strlen(record.race) + 1, file);
        fwrite(record.region, sizeof(char), strlen(record.region) + 1, file);
        fwrite(record.town, sizeof(char), strlen(record.town) + 1, file);
        fwrite(&record.familySize, sizeof(int), 1, file);
        fwrite(&record.fullyVaccinated, sizeof(int), 1, file);
        fwrite(&record.testedPositive, sizeof(int), 1, file);

        top = top->next;
    }

    fclose(file); // Close the file
}

/**
 * It reads all records from a file
 * @param fileName
 */
void displayRecordsFromFile(char fileName[]) {
    // TODO 20: implement displayRecordsFromFile function
    FILE* file = fopen(fileName, "r"); // Open the file for reading

    if (file == NULL) {
        printf("Failed to open the file for reading.\n");
        return;
    }

    int serialNumber = 1;

    // Print the header row with format specifiers
    printf("%-5s %-8s %-20s %-25s %-15s %-15s %s\n",
        "S.No", "Size", "Total Vaccinated", "Total Tested Positive", "Race", "Region", "Town");

    while (!feof(file)) {
        char race[15], region[15], town[15];
        int size, totalVaccinated, totalTestedPositive;

        int fieldsRead = fscanf(file, "%s %s %s %d %d %d", race, region, town, &size, &totalVaccinated, &totalTestedPositive);

        if (fieldsRead == 6) {
            // Print the serial number and the extracted data
            printf("%-5d %-8d %-20d %-25d %-15s %-15s %s\n",
                serialNumber++, size, totalVaccinated, totalTestedPositive, race, region, town);
        }
    }

    fclose(file); // Close the file
}

